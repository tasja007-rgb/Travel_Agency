/**
 * pages/ExpensesPage.jsx
 * ───────────────────────
 * Expense tracker page for Accountants and Admins.
 * Shows the transaction ledger filtered to expenses only,
 * plus a modal form to log new expenses.
 * Includes branch-level summary cards.
 */
import { useState, useMemo } from 'react'
import { useTransactions } from '../hooks/useTransactions'
import ExpenseForm from '../components/shared/ExpenseForm'
import {
  formatBDT, formatDate, capitalize,
  formatDate as fmtDate,
} from '../utils/formatters'
import {
  Plus, X, TrendingDown, Building2,
  Receipt, ChevronDown,
} from 'lucide-react'

const BRANCH_LIST = [
  'All Branches', 'Head Office', 'Dhaka Branch',
  'Khulna Branch', 'Chittagong Branch', 'Sylhet Branch',
]

const CATEGORY_COLORS = {
  rent:            'bg-accent-purple/10 text-accent-purple border-accent-purple/20',
  payroll:         'bg-brand-500/10 text-brand-400 border-brand-500/20',
  marketing:       'bg-accent-orange/10 text-accent-orange border-accent-orange/20',
  utilities:       'bg-accent-gold/10 text-accent-gold border-accent-gold/20',
  office_supplies: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  travel:          'bg-accent-green/10 text-accent-green border-accent-green/20',
  miscellaneous:   'bg-slate-600/10 text-slate-500 border-slate-600/20',
}

export default function ExpensesPage() {
  const { transactions, loading, refetch } = useTransactions(90)  // last 90 days

  const [modalOpen,    setModalOpen]    = useState(false)
  const [branchFilter, setBranchFilter] = useState('All Branches')

  // Only expense transactions
  const expenses = useMemo(() =>
    transactions.filter(tx =>
      tx.type === 'expense' &&
      (branchFilter === 'All Branches' || tx.branch === branchFilter)
    ),
    [transactions, branchFilter]
  )

  // ── Branch summary cards ──────────────────────────────────
  const branchTotals = useMemo(() => {
    const byBranch = {}
    transactions
      .filter(tx => tx.type === 'expense')
      .forEach(tx => {
        if (!byBranch[tx.branch]) byBranch[tx.branch] = 0
        byBranch[tx.branch] += Number(tx.amount)
      })
    return Object.entries(byBranch).sort((a, b) => b[1] - a[1])
  }, [transactions])

  const totalExpenses = expenses.reduce((s, tx) => s + Number(tx.amount), 0)

  return (
    <div className="space-y-6 animate-in">

      {/* ── Page header ──────────────────────────────────────── */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="page-heading">Expense Tracker</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Log and monitor operational costs by branch (last 90 days)
          </p>
        </div>
        <button onClick={() => setModalOpen(true)} className="btn-primary">
          <Plus size={16} />
          Log Expense
        </button>
      </div>

      {/* ── Branch summary cards ──────────────────────────────── */}
      {branchTotals.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {branchTotals.map(([branch, total]) => (
            <button
              key={branch}
              onClick={() =>
                setBranchFilter(b => b === branch ? 'All Branches' : branch)
              }
              className={`card p-4 text-left transition-all duration-200 hover:border-brand-500/40
                ${branchFilter === branch ? 'border-brand-500/60 glow-blue' : ''}`}
            >
              <div className="flex items-center gap-2 mb-2">
                <Building2 size={13} className="text-brand-400" />
                <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold truncate">
                  {branch.replace(' Branch','').replace('Head ','')}
                </span>
              </div>
              <p className="text-lg font-display font-bold text-accent-red tabular-nums">
                {formatBDT(total, true)}
              </p>
              <p className="text-[10px] text-slate-600 mt-0.5">Total expenses</p>
            </button>
          ))}
        </div>
      )}

      {/* ── Filters + total ───────────────────────────────────── */}
      <div className="flex items-center gap-4 flex-wrap">
        <div className="relative">
          <Building2 size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <select
            value={branchFilter}
            onChange={e => setBranchFilter(e.target.value)}
            className="form-input pl-8 pr-8 appearance-none text-sm"
          >
            {BRANCH_LIST.map(b => <option key={b} value={b}>{b}</option>)}
          </select>
          <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
        </div>

        <div className="flex items-center gap-2 ml-auto">
          <TrendingDown size={15} className="text-accent-red" />
          <span className="text-sm text-slate-400">
            Total shown:
          </span>
          <span className="font-bold text-accent-red font-mono tabular-nums">
            {formatBDT(totalExpenses)}
          </span>
          <span className="text-xs text-slate-500">({expenses.length} records)</span>
        </div>
      </div>

      {/* ── Expense table ─────────────────────────────────────── */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Category</th>
                <th>Branch</th>
                <th>Payment</th>
                <th>Reference</th>
                <th className="text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 7 }).map((__, j) => (
                      <td key={j}>
                        <div className="h-3 bg-surface-border rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : expenses.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-14 text-slate-500">
                    <div className="flex flex-col items-center gap-3">
                      <Receipt size={28} className="text-slate-700" />
                      <span>No expense records for this period / branch.</span>
                      <button
                        onClick={() => setModalOpen(true)}
                        className="btn-primary text-xs px-3 py-2"
                      >
                        <Plus size={13} /> Log First Expense
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                expenses.map(tx => (
                  <tr key={tx.id}>
                    <td className="font-mono text-xs text-slate-500 whitespace-nowrap">
                      {formatDate(tx.transaction_date)}
                    </td>
                    <td>
                      <p className="text-slate-200 text-sm max-w-xs truncate">
                        {tx.description}
                      </p>
                    </td>
                    <td>
                      <span className={`badge text-[10px] border
                        ${CATEGORY_COLORS[tx.expense_category] ?? 'bg-slate-500/10 text-slate-400 border-slate-500/20'}`}>
                        {capitalize(tx.expense_category ?? tx.category)}
                      </span>
                    </td>
                    <td className="text-xs text-slate-500 whitespace-nowrap">
                      {tx.branch?.split(' ')[0]}
                    </td>
                    <td className="text-xs text-slate-500 capitalize whitespace-nowrap">
                      {tx.payment_method?.replace('_', ' ')}
                    </td>
                    <td className="font-mono text-xs text-slate-600">
                      {tx.reference_no ?? '—'}
                    </td>
                    <td className="text-right font-mono font-bold text-accent-red tabular-nums">
                      -{formatBDT(tx.amount)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>

            {/* Totals footer row */}
            {expenses.length > 0 && (
              <tfoot>
                <tr className="bg-surface">
                  <td colSpan={6}
                    className="px-4 py-3 text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Total Expenses ({expenses.length} records)
                  </td>
                  <td className="px-4 py-3 text-right font-display font-bold text-accent-red
                                 text-base tabular-nums">
                    -{formatBDT(totalExpenses)}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* ── Log Expense modal ─────────────────────────────────── */}
      {modalOpen && (
        <>
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            onClick={() => setModalOpen(false)}
          />
          <div className="fixed inset-y-0 right-0 w-full max-w-lg bg-surface-card
                          border-l border-surface-border z-50 flex flex-col
                          shadow-2xl animate-in">
            <div className="flex items-center justify-between px-6 py-5
                            border-b border-surface-border flex-shrink-0">
              <div>
                <h3 className="text-lg font-bold text-white">Log Operational Expense</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  All expenses are recorded to the financial ledger
                </p>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="w-8 h-8 rounded-xl flex items-center justify-center
                           text-slate-400 hover:text-white hover:bg-surface-hover transition-colors"
              >
                <X size={18} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-6 py-6">
              <ExpenseForm onClose={() => { setModalOpen(false); refetch() }} />
            </div>
          </div>
        </>
      )}
    </div>
  )
}
