/**
 * pages/VisaPage.jsx
 * ───────────────────
 * Hosts the Visa Pipeline Kanban board.
 * Agents can create new visa bookings via the standard BookingForm
 * (pre-set to visa service type).
 */
import { useState } from 'react'
import VisaKanban from '../components/visa/VisaKanban'
import BookingForm from '../components/booking/BookingForm'
import { Plus, X, Info } from 'lucide-react'

export default function VisaPage() {
  const [modalOpen, setModalOpen] = useState(false)

  return (
    <div className="space-y-6 animate-in">

      {/* ── Page header ─────────────────────────────────────── */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="page-heading">Visa Pipeline</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Drag cards across columns to update processing status
          </p>
        </div>
        <button onClick={() => setModalOpen(true)} className="btn-primary">
          <Plus size={16} />
          New Visa Application
        </button>
      </div>

      {/* ── Info banner ──────────────────────────────────────── */}
      <div className="flex items-start gap-3 px-4 py-3.5 rounded-xl
                      bg-brand-500/5 border border-brand-500/20">
        <Info size={15} className="text-brand-400 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-slate-400">
          <span className="text-brand-300 font-semibold">Tip:</span> Drag and drop visa cards
          between columns to update their status instantly. Use the upload button on each card
          to attach passport copies, bank statements, and other supporting documents.
        </p>
      </div>

      {/* ── Kanban board ─────────────────────────────────────── */}
      <VisaKanban />

      {/* ── New visa booking modal ────────────────────────────── */}
      {modalOpen && (
        <>
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            onClick={() => setModalOpen(false)}
          />
          <div className="fixed inset-y-0 right-0 w-full max-w-2xl bg-surface-card
                          border-l border-surface-border z-50 flex flex-col shadow-2xl animate-in">
            <div className="flex items-center justify-between px-6 py-5
                            border-b border-surface-border flex-shrink-0">
              <div>
                <h3 className="text-lg font-bold text-white">New Visa Application</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Application will appear in Draft column
                </p>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="w-8 h-8 rounded-xl flex items-center justify-center
                           text-slate-400 hover:text-white hover:bg-surface-hover transition-colors"
              >
                <X size={18} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-6 py-6">
              {/* Pre-set service type to 'visa' by passing editData skeleton */}
              <BookingForm
                onClose={() => setModalOpen(false)}
                editData={{ service_type: 'visa', service_details: {} }}
              />
            </div>
          </div>
        </>
      )}
    </div>
  )
}
