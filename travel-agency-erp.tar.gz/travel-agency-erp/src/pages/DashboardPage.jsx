/**
 * pages/DashboardPage.jsx
 * ────────────────────────
 * Renders the main Dashboard component.
 * All data fetching lives in hooks consumed by child components.
 */
import Dashboard from '../components/dashboard/Dashboard'

export default function DashboardPage() {
  return <Dashboard />
}
