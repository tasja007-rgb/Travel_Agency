/**
 * pages/BookingsPage.jsx
 * ───────────────────────
 * Full bookings management page.
 * Lists all bookings and opens a slide-over modal for create/edit.
 */
import { useState } from 'react'
import BookingList from '../components/booking/BookingList'
import BookingForm from '../components/booking/BookingForm'
import { Plus, X } from 'lucide-react'

export default function BookingsPage() {
  const [modalOpen, setModalOpen] = useState(false)
  const [editData,  setEditData]  = useState(null)   // null = create mode

  const openCreate = () => { setEditData(null); setModalOpen(true) }
  const openEdit   = (b) => { setEditData(b);   setModalOpen(true) }
  const closeModal = ()  => { setModalOpen(false); setEditData(null) }

  return (
    <div className="space-y-6 animate-in">

      {/* ── Page header ──────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="page-heading">All Bookings</h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Create, manage, and invoice travel service bookings
          </p>
        </div>
        <button onClick={openCreate} className="btn-primary">
          <Plus size={16} />
          New Booking
        </button>
      </div>

      {/* ── Booking table ─────────────────────────────────────── */}
      <BookingList onEdit={openEdit} />

      {/* ── Slide-over modal ──────────────────────────────────── */}
      {modalOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            onClick={closeModal}
          />

          {/* Panel */}
          <div className="fixed inset-y-0 right-0 w-full max-w-2xl bg-surface-card
                          border-l border-surface-border z-50 flex flex-col
                          shadow-2xl animate-in">
            {/* Panel header */}
            <div className="flex items-center justify-between px-6 py-5
                            border-b border-surface-border flex-shrink-0">
              <div>
                <h3 className="text-lg font-bold text-white">
                  {editData ? 'Edit Booking' : 'New Booking'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {editData ? `Ref: ${editData.booking_ref}` : 'Fill in the details below'}
                </p>
              </div>
              <button
                onClick={closeModal}
                className="w-8 h-8 rounded-xl flex items-center justify-center
                           text-slate-400 hover:text-white hover:bg-surface-hover
                           transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Scrollable form area */}
            <div className="flex-1 overflow-y-auto px-6 py-6">
              <BookingForm onClose={closeModal} editData={editData} />
            </div>
          </div>
        </>
      )}
    </div>
  )
}
