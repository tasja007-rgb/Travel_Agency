/**
 * App.jsx
 * ────────
 * Root component. Declares all routes and wraps them in the
 * shared layout (Sidebar + Header) for authenticated pages.
 */
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './hooks/useAuth'

// Pages
import LoginPage     from './pages/LoginPage'
import DashboardPage from './pages/DashboardPage'
import BookingsPage  from './pages/BookingsPage'
import VisaPage      from './pages/VisaPage'
import ExpensesPage  from './pages/ExpensesPage'

// Shared layout
import Sidebar        from './components/shared/Sidebar'
import Header         from './components/shared/Header'
import ProtectedRoute from './components/shared/ProtectedRoute'

// ── Authenticated App Shell ───────────────────────────────────
function AppShell({ children }) {
  return (
    <div className="flex h-screen overflow-hidden bg-surface">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  )
}

// ── Root Component ────────────────────────────────────────────
export default function App() {
  const { loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-brand-500/20 flex items-center justify-center animate-pulse">
            <span className="text-2xl">✈️</span>
          </div>
          <p className="text-slate-400 text-sm font-medium">Loading workspace…</p>
        </div>
      </div>
    )
  }

  return (
    <Routes>
      {/* Public routes */}
      <Route path="/login" element={<LoginPage />} />

      {/* Protected routes — wrapped in the shared shell */}
      <Route path="/" element={
        <ProtectedRoute>
          <AppShell><DashboardPage /></AppShell>
        </ProtectedRoute>
      } />

      <Route path="/bookings" element={
        <ProtectedRoute>
          <AppShell><BookingsPage /></AppShell>
        </ProtectedRoute>
      } />

      <Route path="/visa" element={
        <ProtectedRoute allowedRoles={['admin', 'manager', 'agent']}>
          <AppShell><VisaPage /></AppShell>
        </ProtectedRoute>
      } />

      <Route path="/expenses" element={
        <ProtectedRoute allowedRoles={['admin', 'accountant', 'manager']}>
          <AppShell><ExpensesPage /></AppShell>
        </ProtectedRoute>
      } />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
