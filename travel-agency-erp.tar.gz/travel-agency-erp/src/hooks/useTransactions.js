/**
 * hooks/useTransactions.js
 * ─────────────────────────
 * Fetches financial transactions and aggregated dashboard metrics.
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabaseClient'

export function useTransactions(days = 30) {
  const [transactions,   setTransactions]   = useState([])
  const [dailyFinancials, setDailyFinancials] = useState([])
  const [salesByCategory, setSalesByCategory] = useState([])
  const [agentLeaderboard, setAgentLeaderboard] = useState([])
  const [todayStats,       setTodayStats]      = useState({ revenue: 0, expenses: 0, profit: 0 })
  const [loading,  setLoading]  = useState(true)
  const [error,    setError]    = useState(null)

  const fetchAll = useCallback(async () => {
    setLoading(true)
    setError(null)

    const since = new Date()
    since.setDate(since.getDate() - days)
    const sinceStr = since.toISOString().split('T')[0]
    const today    = new Date().toISOString().split('T')[0]

    try {
      // ── Recent transactions (ledger) ──────────────────────────
      const { data: txData, error: txErr } = await supabase
        .from('transactions')
        .select(`
          *,
          recorder:users!transactions_recorded_by_fkey(full_name)
        `)
        .gte('transaction_date', sinceStr)
        .order('transaction_date', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(100)

      if (txErr) throw txErr
      setTransactions(txData ?? [])

      // ── Daily financial summary (for the 30-day chart) ─────────
      const { data: dailyData, error: dailyErr } = await supabase
        .from('v_daily_financials')
        .select('*')
        .gte('transaction_date', sinceStr)
        .order('transaction_date', { ascending: true })

      if (dailyErr) throw dailyErr
      setDailyFinancials(dailyData ?? [])

      // ── Today's totals ─────────────────────────────────────────
      const todayRows = (dailyData ?? []).filter(r => r.transaction_date === today)
      const todayRevenue  = todayRows.reduce((s, r) => s + Number(r.total_revenue  ?? 0), 0)
      const todayExpenses = todayRows.reduce((s, r) => s + Number(r.total_expenses ?? 0), 0)
      setTodayStats({
        revenue:  todayRevenue,
        expenses: todayExpenses,
        profit:   todayRevenue - todayExpenses,
      })

      // ── Sales by category (pie chart data) ────────────────────
      const { data: catData, error: catErr } = await supabase
        .from('v_sales_by_category')
        .select('*')

      if (catErr) throw catErr
      setSalesByCategory(catData ?? [])

      // ── Agent leaderboard ──────────────────────────────────────
      const { data: lbData, error: lbErr } = await supabase
        .from('v_agent_leaderboard')
        .select('*')
        .limit(10)

      if (lbErr) throw lbErr
      setAgentLeaderboard(lbData ?? [])

    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [days])

  useEffect(() => { fetchAll() }, [fetchAll])

  // ── Realtime for live transaction ledger ───────────────────────
  useEffect(() => {
    const channel = supabase
      .channel('transactions_realtime')
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'transactions' },
        (payload) => {
          setTransactions(prev => [payload.new, ...prev])
          // Re-fetch aggregates when new transaction arrives
          fetchAll()
        }
      )
      .subscribe()

    return () => supabase.removeChannel(channel)
  }, [fetchAll])

  // ── Create expense transaction ─────────────────────────────────
  const createExpense = async (expenseData) => {
    const { data, error: err } = await supabase
      .from('transactions')
      .insert([{ ...expenseData, type: 'expense' }])
      .select()
      .single()
    if (err) throw new Error(err.message)
    return data
  }

  return {
    transactions, dailyFinancials, salesByCategory, agentLeaderboard,
    todayStats, loading, error,
    refetch: fetchAll, createExpense,
  }
}
