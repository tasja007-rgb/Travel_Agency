/**
 * hooks/useAuth.js
 * ─────────────────
 * Provides the current authenticated user and their business profile.
 * Subscribe to Supabase Auth state changes and fetch the users row.
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabaseClient'

export function useAuth() {
  const [session,  setSession]  = useState(null)
  const [profile,  setProfile]  = useState(null)   // row from public.users
  const [loading,  setLoading]  = useState(true)
  const [error,    setError]    = useState(null)

  // ── Fetch the business profile from public.users ──────────────
  const fetchProfile = useCallback(async (userId) => {
    if (!userId) { setProfile(null); return }
    const { data, error: err } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single()
    if (err) setError(err.message)
    else setProfile(data)
  }, [])

  // ── Listen to Supabase Auth state ─────────────────────────────
  useEffect(() => {
    // Initial session
    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s)
      fetchProfile(s?.user?.id).finally(() => setLoading(false))
    })

    // Realtime changes (login / logout / token refresh)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, s) => {
        setSession(s)
        fetchProfile(s?.user?.id)
      }
    )

    return () => subscription.unsubscribe()
  }, [fetchProfile])

  // ── Auth actions ──────────────────────────────────────────────

  const signIn = async (email, password) => {
    setError(null)
    const { error: err } = await supabase.auth.signInWithPassword({ email, password })
    if (err) { setError(err.message); return false }
    return true
  }

  const signOut = async () => {
    await supabase.auth.signOut()
    setProfile(null)
    setSession(null)
  }

  // ── Convenience role checks ───────────────────────────────────
  const isAdmin      = profile?.role === 'admin'
  const isManager    = profile?.role === 'manager'
  const isAgent      = profile?.role === 'agent'
  const isAccountant = profile?.role === 'accountant'
  const canManage    = isAdmin || isManager      // admin or manager

  return {
    session, profile, loading, error,
    signIn, signOut,
    isAdmin, isManager, isAgent, isAccountant, canManage,
    user: session?.user ?? null,
  }
}
