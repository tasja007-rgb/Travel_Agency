/**
 * hooks/useBookings.js
 * ─────────────────────
 * CRUD operations for the sales_bookings table.
 * Subscribes to realtime inserts/updates for live dashboard.
 */
import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabaseClient'

export function useBookings(filters = {}) {
  const [bookings, setBookings] = useState([])
  const [loading,  setLoading]  = useState(true)
  const [error,    setError]    = useState(null)

  const { serviceType, status, agentId, branch, limit = 50 } = filters

  // ── Fetch bookings with optional filters ──────────────────────
  const fetchBookings = useCallback(async () => {
    setLoading(true)
    setError(null)

    let query = supabase
      .from('sales_bookings')
      .select(`
        *,
        agent:users!sales_bookings_agent_id_fkey(full_name, email, branch)
      `)
      .order('created_at', { ascending: false })
      .limit(limit)

    if (serviceType) query = query.eq('service_type', serviceType)
    if (status)      query = query.eq('booking_status', status)
    if (agentId)     query = query.eq('agent_id', agentId)
    if (branch)      query = query.eq('branch', branch)

    const { data, error: err } = await query
    if (err) setError(err.message)
    else setBookings(data ?? [])
    setLoading(false)
  }, [serviceType, status, agentId, branch, limit])

  // ── Initial load ──────────────────────────────────────────────
  useEffect(() => { fetchBookings() }, [fetchBookings])

  // ── Realtime subscription ─────────────────────────────────────
  useEffect(() => {
    const channel = supabase
      .channel('bookings_realtime')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'sales_bookings' },
        (payload) => {
          setBookings(prev => {
            if (payload.eventType === 'INSERT') {
              return [payload.new, ...prev].slice(0, limit)
            }
            if (payload.eventType === 'UPDATE') {
              return prev.map(b => b.id === payload.new.id ? { ...b, ...payload.new } : b)
            }
            if (payload.eventType === 'DELETE') {
              return prev.filter(b => b.id !== payload.old.id)
            }
            return prev
          })
        }
      )
      .subscribe()

    return () => supabase.removeChannel(channel)
  }, [limit])

  // ── Create a new booking ──────────────────────────────────────
  const createBooking = async (bookingData) => {
    const { data, error: err } = await supabase
      .from('sales_bookings')
      .insert([bookingData])
      .select()
      .single()
    if (err) throw new Error(err.message)
    return data
  }

  // ── Update a booking (status change, visa status, etc.) ───────
  const updateBooking = async (id, updates) => {
    const { data, error: err } = await supabase
      .from('sales_bookings')
      .update(updates)
      .eq('id', id)
      .select()
      .single()
    if (err) throw new Error(err.message)
    return data
  }

  // ── Upload a document to Supabase Storage ─────────────────────
  const uploadDocument = async (bookingId, file) => {
    const ext      = file.name.split('.').pop()
    const fileName = `${bookingId}/${Date.now()}.${ext}`

    const { error: uploadErr } = await supabase.storage
      .from('booking-documents')
      .upload(fileName, file, { cacheControl: '3600', upsert: false })

    if (uploadErr) throw new Error(uploadErr.message)

    // Append the path to the booking's documents array
    const booking = bookings.find(b => b.id === bookingId)
    const existingDocs = booking?.documents ?? []
    await updateBooking(bookingId, { documents: [...existingDocs, fileName] })

    return fileName
  }

  // ── Get a signed URL for a document ──────────────────────────
  const getDocumentUrl = async (path) => {
    const { data } = await supabase.storage
      .from('booking-documents')
      .createSignedUrl(path, 3600)   // valid for 1 hour
    return data?.signedUrl
  }

  return {
    bookings, loading, error,
    refetch: fetchBookings,
    createBooking, updateBooking, uploadDocument, getDocumentUrl,
  }
}
