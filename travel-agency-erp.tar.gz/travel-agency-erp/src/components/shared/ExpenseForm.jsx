/**
 * components/shared/ExpenseForm.jsx
 * ───────────────────────────────────
 * Form for Accountants and Admins to log operational expenses.
 * Tags each expense by category and branch.
 * Writes to the transactions table with type = 'expense'.
 *
 * Props:
 *   onClose  () => void  — called after successful submission
 */
import { useState } from 'react'
import { useAuth } from '../../hooks/useAuth'
import { useTransactions } from '../../hooks/useTransactions'
import { formatBDT } from '../../utils/formatters'
import { CheckCircle2, AlertCircle, Receipt } from 'lucide-react'

const EXPENSE_CATEGORIES = [
  { value: 'rent',           label: '🏢 Rent' },
  { value: 'payroll',        label: '👥 Payroll / Salaries' },
  { value: 'marketing',      label: '📣 Marketing & Ads' },
  { value: 'utilities',      label: '💡 Utilities (Electric, Internet)' },
  { value: 'office_supplies',label: '🖊️ Office Supplies' },
  { value: 'travel',         label: '✈️ Staff Travel' },
  { value: 'miscellaneous',  label: '📦 Miscellaneous' },
]

const PAYMENT_METHODS = [
  { value: 'cash',          label: 'Cash' },
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'card',          label: 'Debit / Credit Card' },
  { value: 'bkash',         label: 'bKash / Mobile Banking' },
  { value: 'cheque',        label: 'Cheque' },
]

const BRANCHES = [
  'Head Office',
  'Dhaka Branch',
  'Khulna Branch',
  'Chittagong Branch',
  'Sylhet Branch',
]

export default function ExpenseForm({ onClose }) {
  const { profile }       = useAuth()
  const { createExpense } = useTransactions()

  // ── Form state ────────────────────────────────────────────
  const [category,        setCategory]        = useState('')
  const [amount,          setAmount]          = useState('')
  const [description,     setDescription]     = useState('')
  const [branch,          setBranch]          = useState(profile?.branch ?? 'Head Office')
  const [paymentMethod,   setPaymentMethod]   = useState('cash')
  const [referenceNo,     setReferenceNo]     = useState('')
  const [transactionDate, setTransactionDate] = useState(
    new Date().toISOString().split('T')[0]   // default to today
  )

  // UI state
  const [loading, setLoading]  = useState(false)
  const [success, setSuccess]  = useState(false)
  const [error,   setError]    = useState(null)

  // ── Submit ────────────────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!category) { setError('Please select an expense category.'); return }
    if (!amount || Number(amount) <= 0) { setError('Amount must be greater than zero.'); return }

    setLoading(true)
    setError(null)

    const catLabel = EXPENSE_CATEGORIES.find(c => c.value === category)?.label
                       .replace(/^[^\w]+/, '') ?? category   // strip emoji for DB

    try {
      await createExpense({
        branch,
        category:         category,
        expense_category: category,
        recorded_by:      profile?.id,
        amount:           Number(amount),
        description:      description.trim() || `${catLabel} — ${branch}`,
        transaction_date: transactionDate,
        payment_method:   paymentMethod,
        reference_no:     referenceNo.trim() || null,
      })
      setSuccess(true)
      setTimeout(() => onClose?.(), 1500)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  // ── Success screen ────────────────────────────────────────
  if (success) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4 animate-in">
        <div className="w-16 h-16 rounded-2xl bg-accent-green/15 flex items-center justify-center">
          <CheckCircle2 size={32} className="text-accent-green" />
        </div>
        <p className="text-white font-semibold text-lg">Expense logged successfully!</p>
        <p className="text-slate-400 text-sm">Closing form…</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">

      {/* ── Category grid ─────────────────────────────────── */}
      <div>
        <label className="form-label">Expense Category *</label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {EXPENSE_CATEGORIES.map(cat => (
            <button
              key={cat.value}
              type="button"
              onClick={() => setCategory(cat.value)}
              className={`px-3 py-2.5 rounded-xl text-sm text-left transition-all duration-150 border
                ${category === cat.value
                  ? 'bg-brand-500/15 border-brand-500/50 text-brand-300'
                  : 'bg-surface border-surface-border text-slate-400 hover:border-brand-500/30 hover:text-slate-200'
                }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Amount ────────────────────────────────────────── */}
      <div>
        <label className="form-label">Amount (BDT) *</label>
        <div className="relative">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">৳</span>
          <input
            type="number"
            min="1"
            step="0.01"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            className="form-input pl-8"
            placeholder="0.00"
            required
          />
        </div>
        {/* Live formatted preview */}
        {amount > 0 && (
          <p className="text-xs text-accent-green mt-1.5 font-mono">
            = {formatBDT(amount)}
          </p>
        )}
      </div>

      {/* ── Description ───────────────────────────────────── */}
      <div>
        <label className="form-label">Description</label>
        <input
          type="text"
          value={description}
          onChange={e => setDescription(e.target.value)}
          className="form-input"
          placeholder="e.g. Office rent — Dhaka Branch — September 2024"
        />
        <p className="text-[10px] text-slate-600 mt-1">
          Leave blank to auto-generate from category + branch.
        </p>
      </div>

      {/* ── Branch + Date ──────────────────────────────────── */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="form-label">Branch *</label>
          <select
            value={branch}
            onChange={e => setBranch(e.target.value)}
            className="form-input"
            required
          >
            {BRANCHES.map(b => <option key={b} value={b}>{b}</option>)}
          </select>
        </div>
        <div>
          <label className="form-label">Transaction Date *</label>
          <input
            type="date"
            value={transactionDate}
            onChange={e => setTransactionDate(e.target.value)}
            className="form-input"
            required
          />
        </div>
      </div>

      {/* ── Payment Method + Reference ─────────────────────── */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="form-label">Payment Method</label>
          <select
            value={paymentMethod}
            onChange={e => setPaymentMethod(e.target.value)}
            className="form-input"
          >
            {PAYMENT_METHODS.map(m => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="form-label">Reference / Receipt No.</label>
          <input
            type="text"
            value={referenceNo}
            onChange={e => setReferenceNo(e.target.value)}
            className="form-input"
            placeholder="Optional"
          />
        </div>
      </div>

      {/* ── Error ─────────────────────────────────────────── */}
      {error && (
        <div className="flex items-start gap-2 px-4 py-3 rounded-xl
                        bg-accent-red/5 border border-accent-red/20 text-sm text-accent-red">
          <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
          {error}
        </div>
      )}

      {/* ── Actions ───────────────────────────────────────── */}
      <div className="flex items-center gap-3 pt-2">
        <button type="submit" className="btn-primary flex-1" disabled={loading}>
          <Receipt size={15} />
          {loading ? 'Saving…' : 'Log Expense'}
        </button>
        <button type="button" className="btn-ghost" onClick={onClose}>
          Cancel
        </button>
      </div>
    </form>
  )
}
