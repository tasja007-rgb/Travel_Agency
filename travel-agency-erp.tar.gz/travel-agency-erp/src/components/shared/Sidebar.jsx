/**
 * components/shared/Sidebar.jsx
 * ──────────────────────────────
 * Left navigation rail with route links and role-aware menu items.
 */
import { NavLink } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'
import {
  LayoutDashboard, Ticket, FileSearch, Receipt,
  Users, Settings, LogOut, Plane,
} from 'lucide-react'

const NAV_ITEMS = [
  { to: '/',         label: 'Dashboard',  icon: LayoutDashboard, roles: ['admin','manager','agent','accountant'] },
  { to: '/bookings', label: 'Bookings',   icon: Ticket,          roles: ['admin','manager','agent','accountant'] },
  { to: '/visa',     label: 'Visa Board', icon: FileSearch,      roles: ['admin','manager','agent'] },
  { to: '/expenses', label: 'Expenses',   icon: Receipt,         roles: ['admin','manager','accountant'] },
]

export default function Sidebar() {
  const { profile, signOut } = useAuth()

  const role = profile?.role ?? 'agent'
  const visibleItems = NAV_ITEMS.filter(item => item.roles.includes(role))

  return (
    <aside className="w-64 flex-shrink-0 bg-surface-card border-r border-surface-border
                      flex flex-col hidden lg:flex">

      {/* ── Logo ─────────────────────────────────────────────── */}
      <div className="px-6 py-5 border-b border-surface-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700
                          flex items-center justify-center shadow-lg shadow-brand-500/30">
            <Plane size={18} className="text-white" />
          </div>
          <div>
            <p className="font-display font-bold text-white text-sm leading-none">Horizon</p>
            <p className="text-[10px] text-slate-500 mt-0.5 uppercase tracking-widest">Travels & Tours</p>
          </div>
        </div>
      </div>

      {/* ── Navigation ───────────────────────────────────────── */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {visibleItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150
              ${isActive
                ? 'bg-brand-500/15 text-brand-400 shadow-inner'
                : 'text-slate-400 hover:text-slate-200 hover:bg-surface-hover'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <Icon size={17} className={isActive ? 'text-brand-400' : 'text-slate-500'} />
                {label}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* ── User profile + sign-out ───────────────────────────── */}
      <div className="p-4 border-t border-surface-border">
        <div className="flex items-center gap-3 px-2 mb-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent-purple to-brand-500
                          flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
            {profile?.full_name?.[0] ?? '?'}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-white truncate">{profile?.full_name ?? 'User'}</p>
            <p className="text-[10px] text-slate-500 capitalize">{profile?.role} · {profile?.branch?.split(' ')[0]}</p>
          </div>
        </div>
        <button
          onClick={signOut}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-slate-400
                     hover:text-accent-red hover:bg-accent-red/5 transition-colors duration-150"
        >
          <LogOut size={13} />
          Sign Out
        </button>
      </div>
    </aside>
  )
}
