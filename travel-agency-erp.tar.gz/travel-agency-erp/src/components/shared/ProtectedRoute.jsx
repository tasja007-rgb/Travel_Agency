/**
 * components/shared/ProtectedRoute.jsx
 * ──────────────────────────────────────
 * Redirects to /login if unauthenticated.
 * Optionally restricts by role (allowedRoles prop).
 */
import { Navigate } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'

export default function ProtectedRoute({ children, allowedRoles }) {
  const { session, profile, loading } = useAuth()

  if (loading) return null  // app-level spinner handles this

  if (!session) {
    return <Navigate to="/login" replace />
  }

  // Role-based access control
  if (allowedRoles && profile && !allowedRoles.includes(profile.role)) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center p-8">
        <div className="card p-8 max-w-sm text-center">
          <div className="text-4xl mb-4">🔒</div>
          <h2 className="text-xl font-bold text-white mb-2">Access Restricted</h2>
          <p className="text-slate-400 text-sm">
            Your role <span className="text-brand-400 font-semibold">({profile.role})</span> does
            not have permission to view this page.
          </p>
        </div>
      </div>
    )
  }

  return children
}
