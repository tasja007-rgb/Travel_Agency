/**
 * components/shared/Header.jsx
 * ─────────────────────────────
 * Top navigation bar showing page context, date and notifications.
 */
import { useLocation } from 'react-router-dom'
import { Bell, Search } from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'

const PAGE_TITLES = {
  '/':         { title: 'Operations Dashboard', sub: 'Live business overview' },
  '/bookings': { title: 'Bookings',             sub: 'All service reservations' },
  '/visa':     { title: 'Visa Pipeline',        sub: 'Kanban tracking board' },
  '/expenses': { title: 'Expense Tracker',      sub: 'Operational cost log' },
}

export default function Header() {
  const { pathname } = useLocation()
  const { profile }  = useAuth()
  const page = PAGE_TITLES[pathname] ?? { title: 'Horizon ERP', sub: '' }

  const now  = new Date()
  const date = now.toLocaleDateString('en-GB', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
  })

  return (
    <header className="bg-surface-card border-b border-surface-border
                       px-6 py-4 flex items-center justify-between flex-shrink-0">

      {/* ── Page title ─────────────────────────────────────── */}
      <div>
        <h1 className="page-heading">{page.title}</h1>
        <p className="text-xs text-slate-500 mt-0.5">{page.sub} · {date}</p>
      </div>

      {/* ── Right side controls ────────────────────────────── */}
      <div className="flex items-center gap-3">

        {/* Branch badge */}
        {profile?.branch && (
          <span className="hidden md:inline-flex badge bg-brand-500/10 text-brand-400
                           border border-brand-500/30 text-[10px]">
            {profile.branch}
          </span>
        )}

        {/* Notification bell (placeholder) */}
        <button className="relative w-9 h-9 rounded-xl bg-surface border border-surface-border
                            flex items-center justify-center text-slate-400 hover:text-white
                            hover:border-brand-500/50 transition-all duration-150">
          <Bell size={16} />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-accent-red" />
        </button>

        {/* Mobile: user avatar */}
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-accent-purple to-brand-500
                        flex items-center justify-center text-white text-xs font-bold lg:hidden">
          {profile?.full_name?.[0] ?? '?'}
        </div>
      </div>
    </header>
  )
}
