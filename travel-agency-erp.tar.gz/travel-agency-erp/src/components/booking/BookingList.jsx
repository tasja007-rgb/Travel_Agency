/**
 * components/booking/BookingList.jsx
 * ────────────────────────────────────
 * Searchable, filterable table of all bookings.
 * Supports editing, status changes, and invoice PDF generation.
 *
 * Props:
 *   onEdit   (booking) => void
 *   onInvoice (booking) => void
 */
import { useState, useMemo } from 'react'
import { useBookings } from '../../hooks/useBookings'
import { useAuth } from '../../hooks/useAuth'
import {
  formatBDT, formatDate, formatServiceType,
  STATUS_STYLES, capitalize
} from '../../utils/formatters'
import { generateInvoicePDF } from '../invoice/InvoiceGenerator'
import {
  Search, Filter, FileText, Pencil,
  ChevronDown, RefreshCw
} from 'lucide-react'

const STATUS_OPTIONS = ['all','pending','confirmed','processing','completed','cancelled','refunded']
const SERVICE_OPTIONS = ['all','air_ticket','hotel','visa','tour_package','esim','car_pickup_drop']

export default function BookingList({ onEdit }) {
  const { bookings, loading, refetch, updateBooking } = useBookings({ limit: 200 })
  const { isAdmin, isManager } = useAuth()

  const [search,  setSearch]  = useState('')
  const [status,  setStatus]  = useState('all')
  const [service, setService] = useState('all')

  // ── Client-side filtering ─────────────────────────────────
  const filtered = useMemo(() => {
    return bookings.filter(b => {
      const matchSearch = !search ||
        b.client_name?.toLowerCase().includes(search.toLowerCase()) ||
        b.booking_ref?.toLowerCase().includes(search.toLowerCase()) ||
        b.client_phone?.includes(search)
      const matchStatus  = status  === 'all' || b.booking_status === status
      const matchService = service === 'all' || b.service_type   === service
      return matchSearch && matchStatus && matchService
    })
  }, [bookings, search, status, service])

  const handleStatusChange = async (booking, newStatus) => {
    try {
      await updateBooking(booking.id, { booking_status: newStatus })
    } catch (e) {
      console.error('Status update failed:', e)
    }
  }

  return (
    <div className="space-y-4">

      {/* ── Filter Bar ─────────────────────────────────────── */}
      <div className="flex flex-wrap gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search by name, ref, phone…"
            className="form-input pl-9"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>

        {/* Status filter */}
        <div className="relative">
          <Filter size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <select className="form-input pl-8 pr-8 appearance-none"
            value={status} onChange={e => setStatus(e.target.value)}>
            {STATUS_OPTIONS.map(s => (
              <option key={s} value={s}>{s === 'all' ? 'All Statuses' : capitalize(s)}</option>
            ))}
          </select>
          <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
        </div>

        {/* Service filter */}
        <div className="relative">
          <select className="form-input pr-8 appearance-none"
            value={service} onChange={e => setService(e.target.value)}>
            {SERVICE_OPTIONS.map(s => (
              <option key={s} value={s}>{s === 'all' ? 'All Services' : formatServiceType(s)}</option>
            ))}
          </select>
          <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
        </div>

        {/* Refresh */}
        <button onClick={refetch} className="btn-ghost" title="Refresh">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* ── Results count ────────────────────────────────────── */}
      <p className="text-xs text-slate-500">
        Showing <span className="text-white font-semibold">{filtered.length}</span> of {bookings.length} bookings
      </p>

      {/* ── Table ────────────────────────────────────────────── */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Ref</th>
                <th>Client</th>
                <th>Service</th>
                <th>Branch</th>
                <th>Revenue</th>
                <th>Profit</th>
                <th>Status</th>
                <th>Date</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 9 }).map((__, j) => (
                      <td key={j}><div className="h-3 bg-surface-border rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-12 text-slate-500">
                    No bookings match your filters.
                  </td>
                </tr>
              ) : (
                filtered.map((b) => (
                  <tr key={b.id}>
                    <td>
                      <span className="font-mono text-xs text-brand-400">{b.booking_ref}</span>
                    </td>
                    <td>
                      <div>
                        <p className="font-medium text-white">{b.client_name}</p>
                        <p className="text-[11px] text-slate-500">{b.client_phone}</p>
                      </div>
                    </td>
                    <td>
                      <span className="text-xs">{formatServiceType(b.service_type)}</span>
                    </td>
                    <td className="text-xs text-slate-500 whitespace-nowrap">
                      {b.branch?.split(' ')[0]}
                    </td>
                    <td className="font-mono font-semibold text-sm tabular-nums text-white">
                      {formatBDT(b.selling_price)}
                    </td>
                    <td className={`font-mono font-semibold text-sm tabular-nums
                      ${Number(b.net_profit) >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
                      {formatBDT(b.net_profit)}
                    </td>
                    <td>
                      {/* Inline status change for admin/manager */}
                      {(isAdmin || isManager) ? (
                        <select
                          value={b.booking_status}
                          onChange={e => handleStatusChange(b, e.target.value)}
                          className={`badge cursor-pointer border-0 bg-transparent text-xs
                            ${STATUS_STYLES[b.booking_status] ?? ''}`}
                        >
                          {['pending','confirmed','processing','completed','cancelled','refunded'].map(s => (
                            <option key={s} value={s}
                              style={{ background: '#1e293b', color: '#f1f5f9' }}>
                              {capitalize(s)}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <span className={`badge ${STATUS_STYLES[b.booking_status] ?? ''}`}>
                          {capitalize(b.booking_status)}
                        </span>
                      )}
                    </td>
                    <td className="text-xs text-slate-500 whitespace-nowrap">
                      {formatDate(b.created_at)}
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Edit */}
                        <button
                          onClick={() => onEdit?.(b)}
                          className="w-7 h-7 rounded-lg flex items-center justify-center
                                     text-slate-400 hover:text-white hover:bg-surface-hover
                                     transition-colors"
                          title="Edit booking"
                        >
                          <Pencil size={13} />
                        </button>
                        {/* Invoice PDF */}
                        <button
                          onClick={() => generateInvoicePDF(b)}
                          className="w-7 h-7 rounded-lg flex items-center justify-center
                                     text-slate-400 hover:text-brand-400 hover:bg-brand-500/10
                                     transition-colors"
                          title="Download invoice PDF"
                        >
                          <FileText size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
