/**
 * components/booking/BookingForm.jsx
 * ────────────────────────────────────
 * Universal booking form that dynamically changes its input fields
 * based on the selected service type.
 *
 * Service-specific field sets:
 *   air_ticket      → PNR, airline, route, dates, passengers, class
 *   hotel           → hotel name, city, check-in/out, rooms, room type
 *   visa            → country, visa type, passport expiry, travel date
 *   tour_package    → package name, destination, dates, pax, inclusions
 *   esim            → country, data plan, provider, activation date
 *   car_pickup_drop → pickup/drop locations, datetime, vehicle type
 *
 * Props:
 *   onClose   () => void   — called after successful submission
 *   editData  object|null  — pre-fill for editing an existing booking
 */
import { useState, useEffect } from 'react'
import { useAuth } from '../../hooks/useAuth'
import { useBookings } from '../../hooks/useBookings'
import { formatBDT } from '../../utils/formatters'
import { X, Calculator, CheckCircle2, AlertCircle } from 'lucide-react'

// ── Service type options ──────────────────────────────────────
const SERVICE_TYPES = [
  { value: 'air_ticket',      label: '✈ Air Ticket' },
  { value: 'hotel',           label: '🏨 Hotel' },
  { value: 'visa',            label: '📋 Visa' },
  { value: 'tour_package',    label: '🌍 Tour Package' },
  { value: 'esim',            label: '📡 eSIM' },
  { value: 'car_pickup_drop', label: '🚗 Car Transfer' },
]

const BRANCHES = ['Dhaka Branch', 'Khulna Branch', 'Chittagong Branch', 'Sylhet Branch', 'Head Office']

// ── Dynamic field definitions per service type ────────────────
// Each field: { name, label, type, required, placeholder, options? }
const SERVICE_FIELDS = {
  air_ticket: [
    { name: 'pnr',            label: 'PNR Code',        type: 'text',   required: true,  placeholder: 'e.g. ABCD12' },
    { name: 'airline',        label: 'Airline',         type: 'text',   required: true,  placeholder: 'e.g. Biman Bangladesh' },
    { name: 'route',          label: 'Route',           type: 'text',   required: true,  placeholder: 'e.g. DAC-DXB' },
    { name: 'departure_date', label: 'Departure Date',  type: 'date',   required: true,  placeholder: '' },
    { name: 'return_date',    label: 'Return Date',     type: 'date',   required: false, placeholder: 'Leave blank for one-way' },
    { name: 'passengers',     label: 'Passengers',      type: 'number', required: true,  placeholder: '1', min: 1 },
    { name: 'class',          label: 'Travel Class',    type: 'select', required: true,  options: ['Economy', 'Business', 'First'] },
  ],
  hotel: [
    { name: 'hotel_name',  label: 'Hotel Name',   type: 'text', required: true,  placeholder: 'e.g. Grand Hyatt Dubai' },
    { name: 'city',        label: 'City',         type: 'text', required: true,  placeholder: 'e.g. Dubai' },
    { name: 'check_in',    label: 'Check-In',     type: 'date', required: true,  placeholder: '' },
    { name: 'check_out',   label: 'Check-Out',    type: 'date', required: true,  placeholder: '' },
    { name: 'rooms',       label: 'No. of Rooms', type: 'number', required: true, placeholder: '1', min: 1 },
    { name: 'room_type',   label: 'Room Type',    type: 'select', required: true, options: ['Standard', 'Superior', 'Deluxe', 'Suite', 'Executive'] },
  ],
  visa: [
    { name: 'country',         label: 'Country',         type: 'text',   required: true, placeholder: 'e.g. United Arab Emirates' },
    { name: 'visa_type',       label: 'Visa Type',       type: 'select', required: true, options: ['Tourist', 'Business', 'Student', 'Work', 'Transit', 'Medical'] },
    { name: 'passport_expiry', label: 'Passport Expiry', type: 'date',   required: true, placeholder: '' },
    { name: 'travel_date',     label: 'Travel Date',     type: 'date',   required: true, placeholder: '' },
    { name: 'duration',        label: 'Visa Duration',   type: 'text',   required: false, placeholder: 'e.g. 30 days / 1 year' },
  ],
  tour_package: [
    { name: 'package_name',    label: 'Package Name',    type: 'text',   required: true, placeholder: 'e.g. Dubai 5D4N All Inclusive' },
    { name: 'destination',     label: 'Destination',     type: 'text',   required: true, placeholder: 'e.g. Dubai, UAE' },
    { name: 'departure_date',  label: 'Departure Date',  type: 'date',   required: true, placeholder: '' },
    { name: 'return_date',     label: 'Return Date',     type: 'date',   required: true, placeholder: '' },
    { name: 'pax',             label: 'No. of Persons',  type: 'number', required: true, placeholder: '1', min: 1 },
    { name: 'inclusions',      label: 'Inclusions',      type: 'text',   required: false, placeholder: 'e.g. Hotel, Flights, Tours, Meals' },
  ],
  esim: [
    { name: 'country',          label: 'Country',         type: 'text',   required: true,  placeholder: 'e.g. Turkey' },
    { name: 'data_plan',        label: 'Data Plan',       type: 'text',   required: true,  placeholder: 'e.g. 10GB / 30 days' },
    { name: 'provider',         label: 'Provider',        type: 'select', required: true,  options: ['Airalo', 'Holafly', 'Maya Mobile', 'Esimplus', 'Other'] },
    { name: 'activation_date',  label: 'Activation Date', type: 'date',   required: true,  placeholder: '' },
  ],
  car_pickup_drop: [
    { name: 'pickup_location',  label: 'Pickup Location', type: 'text',     required: true, placeholder: 'e.g. Hazrat Shahjalal Airport' },
    { name: 'drop_location',    label: 'Drop Location',   type: 'text',     required: true, placeholder: 'e.g. Gulshan 2, Dhaka' },
    { name: 'pickup_datetime',  label: 'Pickup Date/Time',type: 'datetime-local', required: true, placeholder: '' },
    { name: 'vehicle_type',     label: 'Vehicle Type',    type: 'select',   required: true, options: ['Sedan', 'SUV', 'Noah Microbus', 'Hi-Ace', 'Coaster'] },
    { name: 'passengers',       label: 'Passengers',      type: 'number',   required: true, placeholder: '1', min: 1 },
    { name: 'driver_name',      label: 'Driver Name',     type: 'text',     required: false, placeholder: 'Optional' },
  ],
}

// ── Reusable field renderer ───────────────────────────────────
function DynamicField({ field, value, onChange }) {
  const baseClass = 'form-input'

  if (field.type === 'select') {
    return (
      <select
        id={field.name}
        value={value ?? ''}
        onChange={e => onChange(field.name, e.target.value)}
        required={field.required}
        className={baseClass}
      >
        <option value="">Select {field.label}…</option>
        {field.options.map(opt => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </select>
    )
  }

  return (
    <input
      id={field.name}
      type={field.type}
      value={value ?? ''}
      onChange={e => onChange(field.name, e.target.value)}
      required={field.required}
      placeholder={field.placeholder}
      min={field.min}
      className={baseClass}
    />
  )
}

// ── Main BookingForm component ────────────────────────────────
export default function BookingForm({ onClose, editData = null }) {
  const { profile } = useAuth()
  const { createBooking, updateBooking } = useBookings()

  const isEdit = Boolean(editData?.id)

  // ── Form state ────────────────────────────────────────────
  const [serviceType,    setServiceType]    = useState(editData?.service_type ?? 'air_ticket')
  const [clientName,     setClientName]     = useState(editData?.client_name ?? '')
  const [clientPhone,    setClientPhone]    = useState(editData?.client_phone ?? '')
  const [clientEmail,    setClientEmail]    = useState(editData?.client_email ?? '')
  const [clientPassport, setClientPassport] = useState(editData?.client_passport ?? '')
  const [branch,         setBranch]         = useState(editData?.branch ?? profile?.branch ?? 'Head Office')
  const [sellingPrice,   setSellingPrice]   = useState(editData?.selling_price ?? '')
  const [vendorCost,     setVendorCost]     = useState(editData?.vendor_cost ?? '')
  const [notes,          setNotes]          = useState(editData?.notes ?? '')
  const [bookingStatus,  setBookingStatus]  = useState(editData?.booking_status ?? 'pending')

  // Service-specific details (JSONB payload)
  const [serviceDetails, setServiceDetails] = useState(editData?.service_details ?? {})

  // UI state
  const [loading, setLoading]   = useState(false)
  const [success, setSuccess]   = useState(false)
  const [error,   setError]     = useState(null)

  // ── Computed profit ───────────────────────────────────────
  const netProfit = (Number(sellingPrice) || 0) - (Number(vendorCost) || 0)

  // ── Reset service_details when service type changes ───────
  useEffect(() => {
    if (!isEdit) setServiceDetails({})
  }, [serviceType, isEdit])

  // ── Handle dynamic field changes ─────────────────────────
  const handleDetailChange = (fieldName, value) => {
    setServiceDetails(prev => ({ ...prev, [fieldName]: value }))
  }

  // ── Form submission ───────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const payload = {
      agent_id:        profile?.id,
      branch,
      client_name:     clientName.trim(),
      client_phone:    clientPhone.trim(),
      client_email:    clientEmail.trim() || null,
      client_passport: clientPassport.trim() || null,
      service_type:    serviceType,
      booking_status:  bookingStatus,
      selling_price:   Number(sellingPrice),
      vendor_cost:     Number(vendorCost),
      service_details: serviceDetails,
      notes:           notes.trim() || null,
      // Set visa_status for new visa bookings
      ...(serviceType === 'visa' && !isEdit ? { visa_status: 'draft' } : {}),
    }

    try {
      if (isEdit) {
        await updateBooking(editData.id, payload)
      } else {
        await createBooking(payload)
      }
      setSuccess(true)
      setTimeout(() => onClose?.(), 1500)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const currentFields = SERVICE_FIELDS[serviceType] ?? []
  const showPassport  = ['air_ticket', 'visa', 'tour_package'].includes(serviceType)

  // ── Success state ─────────────────────────────────────────
  if (success) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4 animate-in">
        <div className="w-16 h-16 rounded-2xl bg-accent-green/15 flex items-center justify-center">
          <CheckCircle2 size={32} className="text-accent-green" />
        </div>
        <p className="text-white font-semibold text-lg">
          Booking {isEdit ? 'updated' : 'created'} successfully!
        </p>
        <p className="text-slate-400 text-sm">Closing form…</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">

      {/* ── Service Type Selector ─────────────────────────── */}
      <div>
        <label className="form-label">Service Type *</label>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {SERVICE_TYPES.map(({ value, label }) => (
            <button
              key={value}
              type="button"
              onClick={() => setServiceType(value)}
              className={`px-2 py-2.5 rounded-xl text-xs font-medium text-center transition-all duration-150 border
                ${serviceType === value
                  ? 'bg-brand-500/15 border-brand-500/50 text-brand-300'
                  : 'bg-surface border-surface-border text-slate-400 hover:border-brand-500/30 hover:text-slate-200'
                }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Two-column layout for client + logistics ──────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Left: Client Information */}
        <div className="space-y-4">
          <p className="text-xs font-bold text-slate-300 uppercase tracking-widest
                        border-b border-surface-border pb-2">
            Client Details
          </p>

          <div>
            <label htmlFor="clientName" className="form-label">Full Name *</label>
            <input id="clientName" type="text" className="form-input"
              value={clientName} onChange={e => setClientName(e.target.value)}
              placeholder="e.g. Mohammed Hasan" required />
          </div>

          <div>
            <label htmlFor="clientPhone" className="form-label">Phone Number *</label>
            <input id="clientPhone" type="tel" className="form-input"
              value={clientPhone} onChange={e => setClientPhone(e.target.value)}
              placeholder="+880-1700-000000" required />
          </div>

          <div>
            <label htmlFor="clientEmail" className="form-label">Email (optional)</label>
            <input id="clientEmail" type="email" className="form-input"
              value={clientEmail} onChange={e => setClientEmail(e.target.value)}
              placeholder="client@email.com" />
          </div>

          {showPassport && (
            <div>
              <label htmlFor="clientPassport" className="form-label">Passport Number</label>
              <input id="clientPassport" type="text" className="form-input"
                value={clientPassport} onChange={e => setClientPassport(e.target.value)}
                placeholder="e.g. BK0123456" />
            </div>
          )}
        </div>

        {/* Right: Service-specific dynamic fields */}
        <div className="space-y-4">
          <p className="text-xs font-bold text-slate-300 uppercase tracking-widest
                        border-b border-surface-border pb-2">
            {SERVICE_TYPES.find(s => s.value === serviceType)?.label} Details
          </p>

          {currentFields.map(field => (
            <div key={field.name}>
              <label htmlFor={field.name} className="form-label">
                {field.label}{field.required ? ' *' : ''}
              </label>
              <DynamicField
                field={field}
                value={serviceDetails[field.name]}
                onChange={handleDetailChange}
              />
            </div>
          ))}
        </div>
      </div>

      {/* ── Financial Section ─────────────────────────────── */}
      <div className="border border-surface-border rounded-2xl p-4 bg-surface space-y-4">
        <p className="text-xs font-bold text-slate-300 uppercase tracking-widest">
          Financials
        </p>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="form-label">Selling Price (BDT) *</label>
            <input type="number" className="form-input" min="0" step="0.01"
              value={sellingPrice} onChange={e => setSellingPrice(e.target.value)}
              placeholder="0.00" required />
          </div>
          <div>
            <label className="form-label">Vendor Cost (BDT) *</label>
            <input type="number" className="form-input" min="0" step="0.01"
              value={vendorCost} onChange={e => setVendorCost(e.target.value)}
              placeholder="0.00" required />
          </div>
        </div>

        {/* Live profit calculation */}
        {(sellingPrice || vendorCost) && (
          <div className={`flex items-center gap-3 px-4 py-3 rounded-xl border
            ${netProfit >= 0
              ? 'bg-accent-green/5 border-accent-green/20'
              : 'bg-accent-red/5 border-accent-red/20'
            }`}>
            <Calculator size={16} className={netProfit >= 0 ? 'text-accent-green' : 'text-accent-red'} />
            <span className="text-sm text-slate-400">Net Profit:</span>
            <span className={`text-sm font-bold tabular-nums ${netProfit >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
              {formatBDT(netProfit)}
            </span>
            {sellingPrice > 0 && (
              <span className="text-xs text-slate-500">
                ({((netProfit / Number(sellingPrice)) * 100).toFixed(1)}% margin)
              </span>
            )}
          </div>
        )}
      </div>

      {/* ── Metadata ──────────────────────────────────────── */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="form-label">Branch *</label>
          <select value={branch} onChange={e => setBranch(e.target.value)}
            className="form-input" required>
            {BRANCHES.map(b => <option key={b} value={b}>{b}</option>)}
          </select>
        </div>
        <div>
          <label className="form-label">Status</label>
          <select value={bookingStatus} onChange={e => setBookingStatus(e.target.value)}
            className="form-input">
            {['pending','confirmed','processing','completed','cancelled'].map(s => (
              <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label className="form-label">Notes (optional)</label>
        <textarea className="form-input min-h-[80px] resize-none" rows={3}
          value={notes} onChange={e => setNotes(e.target.value)}
          placeholder="Internal notes, special instructions…" />
      </div>

      {/* ── Error ─────────────────────────────────────────── */}
      {error && (
        <div className="flex items-start gap-2 px-4 py-3 rounded-xl bg-accent-red/5 border border-accent-red/20 text-sm text-accent-red">
          <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
          {error}
        </div>
      )}

      {/* ── Actions ───────────────────────────────────────── */}
      <div className="flex items-center gap-3 pt-2">
        <button type="submit" className="btn-primary flex-1" disabled={loading}>
          {loading
            ? 'Saving…'
            : isEdit ? 'Update Booking' : 'Create Booking'
          }
        </button>
        <button type="button" className="btn-ghost" onClick={onClose}>
          Cancel
        </button>
      </div>
    </form>
  )
}
