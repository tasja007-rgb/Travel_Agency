/**
 * components/visa/VisaKanban.jsx
 * ───────────────────────────────
 * Drag-and-drop Kanban board for visa pipeline management.
 * Columns: Draft → Ready → Processing → Approved / Rejected
 *
 * Uses @dnd-kit for accessible drag-and-drop.
 * Document uploads go to Supabase Storage (booking-documents bucket).
 */
import { useState, useMemo } from 'react'
import {
  DndContext, closestCorners, PointerSensor,
  useSensor, useSensors, DragOverlay,
} from '@dnd-kit/core'
import {
  SortableContext, verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { useBookings } from '../../hooks/useBookings'
import { formatDate, VISA_STATUS_STYLES, capitalize } from '../../utils/formatters'
import {
  Upload, FileText, GripVertical, User,
  Globe, Calendar, CheckCircle2, XCircle,
  Clock, AlertCircle, RefreshCw,
} from 'lucide-react'

// ── Column definitions ────────────────────────────────────────
const COLUMNS = [
  {
    id:    'draft',
    label: 'Draft',
    icon:  Clock,
    color: 'text-slate-400',
    bg:    'bg-slate-500/5 border-slate-500/20',
    dot:   'bg-slate-400',
  },
  {
    id:    'ready',
    label: 'Ready to Submit',
    icon:  AlertCircle,
    color: 'text-accent-gold',
    bg:    'bg-accent-gold/5 border-accent-gold/20',
    dot:   'bg-accent-gold',
  },
  {
    id:    'processing',
    label: 'Processing',
    icon:  RefreshCw,
    color: 'text-accent-purple',
    bg:    'bg-accent-purple/5 border-accent-purple/20',
    dot:   'bg-accent-purple',
  },
  {
    id:    'approved',
    label: 'Approved',
    icon:  CheckCircle2,
    color: 'text-accent-green',
    bg:    'bg-accent-green/5 border-accent-green/20',
    dot:   'bg-accent-green',
  },
  {
    id:    'rejected',
    label: 'Rejected',
    icon:  XCircle,
    color: 'text-accent-red',
    bg:    'bg-accent-red/5 border-accent-red/20',
    dot:   'bg-accent-red',
  },
]

// ── Single visa card (draggable) ──────────────────────────────
function VisaCard({ booking, onUpload, isDragging = false }) {
  const {
    attributes, listeners, setNodeRef,
    transform, transition,
  } = useSortable({ id: booking.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  const d = booking.service_details ?? {}
  const [uploading, setUploading] = useState(false)

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    try {
      await onUpload(booking.id, file)
    } finally {
      setUploading(false)
      e.target.value = ''
    }
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="card p-4 space-y-3 cursor-default select-none
                 hover:border-brand-500/30 transition-all duration-200 animate-in"
    >
      {/* Drag handle + country */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-1.5">
          {/* Drag grip */}
          <button
            {...attributes}
            {...listeners}
            className="text-slate-600 hover:text-slate-400 cursor-grab active:cursor-grabbing
                       p-0.5 rounded transition-colors"
            title="Drag to reorder"
          >
            <GripVertical size={14} />
          </button>
          <div className="flex items-center gap-1.5">
            <Globe size={13} className="text-brand-400 flex-shrink-0" />
            <span className="font-semibold text-white text-sm">
              {d.country ?? '—'}
            </span>
          </div>
        </div>
        <span className="badge text-[10px] bg-brand-500/10 text-brand-400 border border-brand-500/20">
          {d.visa_type ?? 'Visa'}
        </span>
      </div>

      {/* Client */}
      <div className="flex items-center gap-2">
        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-accent-purple to-brand-500
                        flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0">
          {booking.client_name?.[0] ?? '?'}
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium text-white truncate">{booking.client_name}</p>
          <p className="text-[10px] text-slate-500">{booking.client_phone}</p>
        </div>
      </div>

      {/* Dates */}
      <div className="flex items-center gap-3 text-[10px] text-slate-500">
        <span className="flex items-center gap-1">
          <Calendar size={10} />
          Travel: {formatDate(d.travel_date)}
        </span>
        {booking.client_passport && (
          <span className="flex items-center gap-1">
            <FileText size={10} />
            {booking.client_passport}
          </span>
        )}
      </div>

      {/* Documents */}
      {booking.documents?.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {booking.documents.map((doc, i) => {
            const name = doc.split('/').pop()
            return (
              <span key={i}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg
                           bg-surface text-[10px] text-slate-400 border border-surface-border">
                <FileText size={9} />
                {name.length > 18 ? name.slice(0, 18) + '…' : name}
              </span>
            )
          })}
        </div>
      )}

      {/* Upload button */}
      <label className={`flex items-center gap-2 px-3 py-2 rounded-xl border border-dashed
        border-surface-border text-[11px] text-slate-500 cursor-pointer
        hover:border-brand-500/50 hover:text-brand-400 transition-all duration-150
        ${uploading ? 'opacity-50 pointer-events-none' : ''}`}>
        <Upload size={12} />
        {uploading ? 'Uploading…' : 'Attach document'}
        <input
          type="file"
          className="hidden"
          accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
          onChange={handleFileChange}
          disabled={uploading}
        />
      </label>

      {/* Booking ref */}
      <p className="text-[10px] text-slate-600 font-mono">{booking.booking_ref}</p>
    </div>
  )
}

// ── Kanban column ─────────────────────────────────────────────
function KanbanColumn({ column, cards, onUpload }) {
  const Icon = column.icon
  const cardIds = cards.map(c => c.id)

  return (
    <div className={`rounded-2xl border p-4 min-h-[300px] flex flex-col gap-3 ${column.bg}`}>
      {/* Column header */}
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${column.dot}`} />
          <Icon size={14} className={column.color} />
          <span className={`text-xs font-bold uppercase tracking-wider ${column.color}`}>
            {column.label}
          </span>
        </div>
        <span className="text-[10px] font-bold text-slate-500 bg-surface-card
                         px-2 py-0.5 rounded-full border border-surface-border">
          {cards.length}
        </span>
      </div>

      {/* Cards drop zone */}
      <SortableContext items={cardIds} strategy={verticalListSortingStrategy}>
        <div className="flex flex-col gap-3 flex-1">
          {cards.length === 0 ? (
            <div className="flex-1 flex items-center justify-center py-8
                            border-2 border-dashed border-surface-border/40 rounded-xl">
              <p className="text-xs text-slate-600">Drop cards here</p>
            </div>
          ) : (
            cards.map(card => (
              <VisaCard key={card.id} booking={card} onUpload={onUpload} />
            ))
          )}
        </div>
      </SortableContext>
    </div>
  )
}

// ── Main VisaKanban component ─────────────────────────────────
export default function VisaKanban() {
  const { bookings, loading, updateBooking, uploadDocument, refetch } = useBookings({
    serviceType: 'visa',
    limit: 200,
  })

  const [activeId,    setActiveId]    = useState(null)
  const [movingId,    setMovingId]    = useState(null)

  // ── DnD sensors ────────────────────────────────────────────
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 8 },  // small drag threshold prevents accidental drags
    })
  )

  // ── Group bookings by visa_status ───────────────────────────
  const grouped = useMemo(() => {
    const groups = {}
    COLUMNS.forEach(col => { groups[col.id] = [] })
    bookings.forEach(b => {
      const col = b.visa_status ?? 'draft'
      if (groups[col]) groups[col].push(b)
    })
    return groups
  }, [bookings])

  const activeBooking = bookings.find(b => b.id === activeId)

  // ── Find which column a card belongs to ─────────────────────
  const findColumn = (id) => {
    for (const col of COLUMNS) {
      if (grouped[col.id]?.some(b => b.id === id)) return col.id
    }
    return null
  }

  // ── Drag handlers ───────────────────────────────────────────
  const handleDragStart = ({ active }) => setActiveId(active.id)

  const handleDragEnd = async ({ active, over }) => {
    setActiveId(null)
    if (!over) return

    const fromCol = findColumn(active.id)
    // Determine destination column — `over` could be a column ID or a card ID
    const toCol = COLUMNS.find(c => c.id === over.id)?.id ?? findColumn(over.id)

    if (!toCol || fromCol === toCol) return

    setMovingId(active.id)
    try {
      await updateBooking(active.id, { visa_status: toCol })
    } catch (e) {
      console.error('Failed to update visa status:', e)
    } finally {
      setMovingId(null)
    }
  }

  // ── Document upload handler ─────────────────────────────────
  const handleUpload = async (bookingId, file) => {
    try {
      await uploadDocument(bookingId, file)
    } catch (e) {
      console.error('Upload failed:', e)
    }
  }

  // ── Stats bar ───────────────────────────────────────────────
  const total    = bookings.length
  const approved = grouped['approved']?.length ?? 0
  const rejected = grouped['rejected']?.length ?? 0
  const pending  = (grouped['draft']?.length ?? 0) +
                   (grouped['ready']?.length ?? 0) +
                   (grouped['processing']?.length ?? 0)

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-xl border-2 border-surface-border border-t-brand-500 animate-spin" />
          <p className="text-slate-500 text-sm">Loading visa pipeline…</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">

      {/* ── Summary stats ────────────────────────────────────── */}
      <div className="flex flex-wrap items-center gap-4">
        {[
          { label: 'Total',      value: total,    color: 'text-white' },
          { label: 'In Progress', value: pending, color: 'text-accent-gold' },
          { label: 'Approved',   value: approved, color: 'text-accent-green' },
          { label: 'Rejected',   value: rejected, color: 'text-accent-red' },
        ].map(s => (
          <div key={s.label} className="card px-4 py-2.5 flex items-center gap-2">
            <span className={`text-lg font-display font-bold tabular-nums ${s.color}`}>
              {s.value}
            </span>
            <span className="text-xs text-slate-500">{s.label}</span>
          </div>
        ))}
        <button onClick={refetch} className="btn-ghost ml-auto">
          <RefreshCw size={14} />
          Refresh
        </button>
      </div>

      {/* ── Kanban board (horizontal scroll on small screens) ── */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4
                        overflow-x-auto pb-2">
          {COLUMNS.map(col => (
            <KanbanColumn
              key={col.id}
              column={col}
              cards={grouped[col.id] ?? []}
              onUpload={handleUpload}
            />
          ))}
        </div>

        {/* ── Drag overlay (ghost card while dragging) ───────── */}
        <DragOverlay dropAnimation={null}>
          {activeBooking ? (
            <div className="opacity-90 rotate-2 scale-105 pointer-events-none">
              <VisaCard booking={activeBooking} onUpload={() => {}} isDragging />
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>

      {/* ── Legend ────────────────────────────────────────────── */}
      <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
        <span className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">
          Drag cards between columns to update status
        </span>
        {COLUMNS.map(col => (
          <span key={col.id} className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${col.dot}`} />
            {col.label}
          </span>
        ))}
      </div>
    </div>
  )
}
