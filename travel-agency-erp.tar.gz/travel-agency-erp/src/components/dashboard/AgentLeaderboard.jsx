/**
 * components/dashboard/AgentLeaderboard.jsx
 * ───────────────────────────────────────────
 * Rankings of agents by profit generated.
 * Fetched from the v_agent_leaderboard DB view.
 *
 * Props:
 *   agents   array from v_agent_leaderboard
 *   loading  boolean
 */
import { formatBDT, formatMargin } from '../../utils/formatters'
import { Trophy } from 'lucide-react'

// Rank medal colors
const RANK_STYLES = [
  'bg-accent-gold/20 text-accent-gold border border-accent-gold/40',       // 1st
  'bg-slate-400/10 text-slate-300 border border-slate-400/30',              // 2nd
  'bg-orange-800/20 text-orange-400 border border-orange-600/30',           // 3rd
]

export default function AgentLeaderboard({ agents = [], loading }) {
  return (
    <div className="card overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-surface-border flex items-center gap-2">
        <Trophy size={15} className="text-accent-gold" />
        <div>
          <p className="card-title">Agent Leaderboard</p>
          <p className="text-xs text-slate-500 mt-0.5">Ranked by total profit generated</p>
        </div>
      </div>

      {/* List */}
      <div className="divide-y divide-surface-border/50">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="px-5 py-4 flex items-center gap-4 animate-pulse">
              <div className="w-6 h-6 rounded-lg bg-surface-border" />
              <div className="w-8 h-8 rounded-full bg-surface-border" />
              <div className="flex-1 space-y-1.5">
                <div className="h-3 bg-surface-border rounded w-28" />
                <div className="h-2.5 bg-surface-border rounded w-20" />
              </div>
              <div className="h-4 bg-surface-border rounded w-16" />
            </div>
          ))
        ) : agents.length === 0 ? (
          <div className="px-5 py-8 text-center text-slate-500 text-sm">
            No agent data available.
          </div>
        ) : (
          agents.map((agent, idx) => {
            // Progress bar — relative to top agent
            const topProfit  = Number(agents[0]?.total_profit ?? 1)
            const pct        = Math.max(5, (Number(agent.total_profit) / topProfit) * 100)

            return (
              <div key={agent.agent_id} className="px-5 py-3.5 flex items-center gap-3 hover:bg-surface-hover transition-colors">
                {/* Rank badge */}
                <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold flex-shrink-0
                  ${RANK_STYLES[idx] ?? 'bg-surface-border text-slate-400 border border-surface-border'}`}>
                  {idx + 1}
                </span>

                {/* Avatar */}
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent-purple to-brand-500
                                flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {agent.full_name?.[0] ?? '?'}
                </div>

                {/* Name + progress */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{agent.full_name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    {/* Progress bar */}
                    <div className="flex-1 h-1 rounded-full bg-surface-border overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-brand-500 to-accent-purple"
                        style={{ width: `${pct}%`, transition: 'width 0.8s ease' }}
                      />
                    </div>
                    <span className="text-[10px] text-slate-500 flex-shrink-0">
                      {agent.total_bookings} bookings
                    </span>
                  </div>
                </div>

                {/* Profit figure */}
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-bold text-accent-green tabular-nums">
                    {formatBDT(agent.total_profit, true)}
                  </p>
                  <p className="text-[10px] text-slate-500 tabular-nums">
                    Comm: {formatBDT(agent.commission_earned, true)}
                  </p>
                </div>
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}
