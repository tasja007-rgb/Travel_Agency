/**
 * components/dashboard/Dashboard.jsx
 * ─────────────────────────────────────
 * Assembles the full 3-row dashboard layout:
 *   Row 1 — PulseMetrics (KPI cards)
 *   Row 2 — SalesPieChart + RevenueTrendChart
 *   Row 3 — TransactionsTable + AgentLeaderboard
 */
import PulseMetrics      from './PulseMetrics'
import SalesPieChart     from './SalesPieChart'
import RevenueTrendChart from './RevenueTrendChart'
import TransactionsTable from './TransactionsTable'
import AgentLeaderboard  from './AgentLeaderboard'
import { useTransactions } from '../../hooks/useTransactions'
import { useBookings }      from '../../hooks/useBookings'

export default function Dashboard() {
  // Financial data
  const {
    transactions, dailyFinancials, salesByCategory,
    agentLeaderboard, todayStats, loading: txLoading,
  } = useTransactions(30)

  // Pending booking count for the KPI card
  const { bookings: pendingBookings, loading: bLoading } = useBookings({ status: 'pending', limit: 200 })
  const pendingCount = pendingBookings.length

  const loading = txLoading || bLoading

  return (
    <div className="space-y-6">

      {/* ── Row 1: Pulse Metrics ──────────────────────────────── */}
      <PulseMetrics
        todayStats={todayStats}
        pendingCount={pendingCount}
        loading={loading}
      />

      {/* ── Row 2: Charts ─────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Pie chart — narrower column */}
        <div className="lg:col-span-2">
          <SalesPieChart data={salesByCategory} loading={loading} />
        </div>
        {/* Line graph — wider column */}
        <div className="lg:col-span-3">
          <RevenueTrendChart data={dailyFinancials} loading={loading} />
        </div>
      </div>

      {/* ── Row 3: Ledger + Leaderboard ───────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Live transaction table — wider */}
        <div className="lg:col-span-3">
          <TransactionsTable transactions={transactions} loading={txLoading} />
        </div>
        {/* Agent rankings — narrower */}
        <div className="lg:col-span-2">
          <AgentLeaderboard agents={agentLeaderboard} loading={txLoading} />
        </div>
      </div>
    </div>
  )
}
