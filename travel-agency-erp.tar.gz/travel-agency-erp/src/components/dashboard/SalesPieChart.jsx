/**
 * components/dashboard/SalesPieChart.jsx
 * ───────────────────────────────────────
 * Recharts PieChart — "Sales by Category" breakdown.
 * Shows booking count and revenue share per service type.
 *
 * Props:
 *   data    array from v_sales_by_category view
 *   loading boolean
 */
import {
  PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer
} from 'recharts'
import { formatBDT, formatServiceType } from '../../utils/formatters'

// Distinct colour palette for each service type
const SERVICE_COLORS = {
  air_ticket:      '#0ea5e9',   // sky blue
  hotel:           '#8b5cf6',   // violet
  visa:            '#f59e0b',   // amber
  tour_package:    '#10b981',   // emerald
  esim:            '#f97316',   // orange
  car_pickup_drop: '#ec4899',   // pink
}

// Custom tooltip rendered on hover
function CustomTooltip({ active, payload }) {
  if (!active || !payload?.length) return null
  const item = payload[0].payload
  return (
    <div className="card px-4 py-3 text-xs shadow-2xl border-brand-500/30">
      <p className="font-semibold text-white mb-1">{formatServiceType(item.service_type)}</p>
      <p className="text-slate-400">Bookings: <span className="text-white">{item.booking_count}</span></p>
      <p className="text-slate-400">Revenue:  <span className="text-white">{formatBDT(item.total_revenue)}</span></p>
      <p className="text-slate-400">Profit:   <span className="text-accent-green">{formatBDT(item.total_profit)}</span></p>
    </div>
  )
}

// Custom legend item
function CustomLegend({ payload }) {
  return (
    <ul className="flex flex-col gap-1.5 text-xs mt-2">
      {payload.map((entry) => (
        <li key={entry.value} className="flex items-center gap-2 text-slate-400">
          <span
            className="w-2.5 h-2.5 rounded-full flex-shrink-0"
            style={{ backgroundColor: entry.color }}
          />
          {formatServiceType(entry.value)}
        </li>
      ))}
    </ul>
  )
}

export default function SalesPieChart({ data = [], loading }) {
  // Recharts needs a `value` field — use booking_count for slice sizes
  const chartData = data.map(row => ({
    ...row,
    name:  row.service_type,
    value: Number(row.booking_count),
  }))

  return (
    <div className="card p-5 h-full">
      <p className="card-title mb-1">Sales by Category</p>
      <p className="text-xs text-slate-500 mb-4">Booking distribution across service types</p>

      {loading ? (
        <div className="h-48 flex items-center justify-center">
          <div className="w-32 h-32 rounded-full border-4 border-surface-border
                          border-t-brand-500 animate-spin" />
        </div>
      ) : chartData.length === 0 ? (
        <div className="h-48 flex items-center justify-center">
          <p className="text-slate-500 text-sm">No booking data yet</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={220}>
          <PieChart>
            <Pie
              data={chartData}
              cx="45%"
              cy="50%"
              innerRadius={55}   // donut style
              outerRadius={88}
              paddingAngle={3}
              dataKey="value"
              stroke="none"
            >
              {chartData.map((entry) => (
                <Cell
                  key={entry.service_type}
                  fill={SERVICE_COLORS[entry.service_type] ?? '#64748b'}
                />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend
              layout="vertical"
              align="right"
              verticalAlign="middle"
              iconType="circle"
              content={<CustomLegend />}
              dataKey="name"
            />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  )
}
