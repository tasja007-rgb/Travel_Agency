/**
 * components/dashboard/RevenueTrendChart.jsx
 * ────────────────────────────────────────────
 * Recharts LineChart — 30-day "Revenue vs Expense" trend.
 * Aggregates data across all branches unless filtered.
 *
 * Props:
 *   data    array from v_daily_financials view
 *   loading boolean
 */
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, ReferenceLine,
} from 'recharts'
import { format } from 'date-fns'
import { formatBDT } from '../../utils/formatters'

// Aggregate multiple-branch rows for the same date into one point
function aggregateByDate(rawData) {
  const byDate = {}
  for (const row of rawData) {
    const d = row.transaction_date
    if (!byDate[d]) byDate[d] = { date: d, revenue: 0, expenses: 0, profit: 0 }
    byDate[d].revenue  += Number(row.total_revenue  ?? 0)
    byDate[d].expenses += Number(row.total_expenses ?? 0)
    byDate[d].profit   += Number(row.net_profit     ?? 0)
  }
  return Object.values(byDate).sort((a, b) => a.date.localeCompare(b.date))
}

// Custom tooltip
function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div className="card px-4 py-3 text-xs shadow-2xl border-brand-500/30">
      <p className="font-semibold text-white mb-2">
        {label ? format(new Date(label), 'dd MMM yyyy') : ''}
      </p>
      {payload.map((p) => (
        <p key={p.name} style={{ color: p.color }} className="mb-0.5">
          {p.name}: {formatBDT(p.value)}
        </p>
      ))}
    </div>
  )
}

export default function RevenueTrendChart({ data = [], loading }) {
  const chartData = aggregateByDate(data)

  // Format x-axis ticks to short date labels
  const formatXAxis = (dateStr) => {
    try { return format(new Date(dateStr), 'dd MMM') } catch { return dateStr }
  }

  // Format Y-axis to compact BDT
  const formatYAxis = (val) => {
    if (val >= 100000) return '৳' + (val / 100000).toFixed(0) + 'L'
    if (val >= 1000)   return '৳' + (val / 1000).toFixed(0) + 'K'
    return '৳' + val
  }

  return (
    <div className="card p-5 h-full">
      <p className="card-title mb-1">Revenue vs Expenses — 30 Days</p>
      <p className="text-xs text-slate-500 mb-4">Combined across all branches</p>

      {loading ? (
        <div className="h-56 flex items-center justify-center">
          <div className="text-slate-500 text-sm animate-pulse">Loading trend data…</div>
        </div>
      ) : chartData.length === 0 ? (
        <div className="h-56 flex items-center justify-center">
          <p className="text-slate-500 text-sm">No transaction data for this period</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={230}>
          <LineChart data={chartData} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" vertical={false} />

            <XAxis
              dataKey="date"
              tickFormatter={formatXAxis}
              tick={{ fill: '#64748b', fontSize: 10 }}
              axisLine={{ stroke: '#1e293b' }}
              tickLine={false}
              interval="preserveStartEnd"
            />

            <YAxis
              tickFormatter={formatYAxis}
              tick={{ fill: '#64748b', fontSize: 10 }}
              axisLine={false}
              tickLine={false}
              width={52}
            />

            <Tooltip content={<CustomTooltip />} />

            <Legend
              iconType="circle"
              iconSize={8}
              wrapperStyle={{ fontSize: '11px', color: '#94a3b8', paddingTop: '8px' }}
            />

            {/* Zero profit reference line */}
            <ReferenceLine y={0} stroke="#334155" strokeDasharray="4 4" />

            <Line
              type="monotone"
              dataKey="revenue"
              name="Revenue"
              stroke="#0ea5e9"
              strokeWidth={2.5}
              dot={false}
              activeDot={{ r: 5, strokeWidth: 0, fill: '#0ea5e9' }}
            />

            <Line
              type="monotone"
              dataKey="expenses"
              name="Expenses"
              stroke="#ef4444"
              strokeWidth={2}
              strokeDasharray="5 3"
              dot={false}
              activeDot={{ r: 5, strokeWidth: 0, fill: '#ef4444' }}
            />

            <Line
              type="monotone"
              dataKey="profit"
              name="Net Profit"
              stroke="#10b981"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 5, strokeWidth: 0, fill: '#10b981' }}
            />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  )
}
