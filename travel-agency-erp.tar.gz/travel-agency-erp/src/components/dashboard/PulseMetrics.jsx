/**
 * components/dashboard/PulseMetrics.jsx
 * ───────────────────────────────────────
 * Top row of the dashboard — 4 real-time KPI cards:
 * Daily Revenue, Daily Expenses, Net Profit, Pending Bookings.
 *
 * Props:
 *   todayStats   { revenue, expenses, profit } — from useTransactions
 *   pendingCount number — count of pending bookings
 *   loading      boolean
 */
import { TrendingUp, TrendingDown, BadgeDollarSign, Clock } from 'lucide-react'
import { formatBDT } from '../../utils/formatters'

// ── Individual metric card ────────────────────────────────────
function MetricCard({ label, value, icon: Icon, colorClass, glowClass, change, loading }) {
  return (
    <div className={`metric-card ${glowClass} animate-in`}>
      <div className="flex items-start justify-between">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${colorClass}`}>
          <Icon size={20} />
        </div>
        {change != null && (
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full
            ${change >= 0
              ? 'bg-accent-green/10 text-accent-green'
              : 'bg-accent-red/10 text-accent-red'
            }`}>
            {change >= 0 ? '▲' : '▼'} {Math.abs(change)}%
          </span>
        )}
      </div>

      {loading ? (
        <div className="h-8 w-32 bg-surface-border rounded-lg animate-pulse mt-2" />
      ) : (
        <p className="text-2xl font-display font-bold text-white mt-2 tabular-nums">
          {value}
        </p>
      )}

      <p className="text-xs text-slate-500 font-medium">{label}</p>
    </div>
  )
}

// ── Main export ───────────────────────────────────────────────
export default function PulseMetrics({ todayStats, pendingCount = 0, loading }) {
  const metrics = [
    {
      label:      "Today's Revenue",
      value:      formatBDT(todayStats?.revenue ?? 0),
      icon:       BadgeDollarSign,
      colorClass: 'bg-brand-500/15 text-brand-400',
      glowClass:  'hover:glow-blue',
      change:     null,
    },
    {
      label:      "Today's Expenses",
      value:      formatBDT(todayStats?.expenses ?? 0),
      icon:       TrendingDown,
      colorClass: 'bg-accent-red/15 text-accent-red',
      glowClass:  'hover:glow-red',
      change:     null,
    },
    {
      label:      'Net Profit Today',
      value:      formatBDT(todayStats?.profit ?? 0),
      icon:       TrendingUp,
      colorClass: (todayStats?.profit ?? 0) >= 0
                    ? 'bg-accent-green/15 text-accent-green'
                    : 'bg-accent-red/15 text-accent-red',
      glowClass:  (todayStats?.profit ?? 0) >= 0 ? 'hover:glow-green' : 'hover:glow-red',
      change:     null,
    },
    {
      label:      'Pending Actions',
      value:      pendingCount,
      icon:       Clock,
      colorClass: 'bg-accent-gold/15 text-accent-gold',
      glowClass:  'hover:glow-gold',
      change:     null,
    },
  ]

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((m, i) => (
        <div key={m.label} style={{ animationDelay: `${i * 0.05}s` }}>
          <MetricCard {...m} loading={loading} />
        </div>
      ))}
    </div>
  )
}
