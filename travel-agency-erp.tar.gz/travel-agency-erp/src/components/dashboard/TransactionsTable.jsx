/**
 * components/dashboard/TransactionsTable.jsx
 * ────────────────────────────────────────────
 * Live-updating financial ledger showing recent transactions.
 * Revenue rows are highlighted in blue, expenses in red.
 *
 * Props:
 *   transactions  array from useTransactions
 *   loading       boolean
 */
import { formatBDT, formatDate, capitalize } from '../../utils/formatters'
import { ArrowUpRight, ArrowDownRight } from 'lucide-react'

export default function TransactionsTable({ transactions = [], loading }) {
  return (
    <div className="card overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-surface-border flex items-center justify-between">
        <div>
          <p className="card-title">Recent Transactions</p>
          <p className="text-xs text-slate-500 mt-0.5">Live financial ledger</p>
        </div>
        {/* Live indicator */}
        <div className="flex items-center gap-1.5 text-[10px] text-accent-green font-semibold uppercase tracking-wider">
          <span className="w-1.5 h-1.5 rounded-full bg-accent-green animate-pulse" />
          Live
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto max-h-72 overflow-y-auto">
        {loading ? (
          <div className="p-8 text-center text-slate-500 text-sm">Loading transactions…</div>
        ) : transactions.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-sm">No transactions recorded yet.</div>
        ) : (
          <table className="data-table">
            <thead className="sticky top-0 bg-surface-card z-10">
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Category</th>
                <th>Branch</th>
                <th className="text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx) => {
                const isRevenue = tx.type === 'revenue'
                return (
                  <tr key={tx.id} className="group">
                    <td className="font-mono text-xs text-slate-500">
                      {formatDate(tx.transaction_date)}
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        {/* Type icon */}
                        <span className={`flex-shrink-0 w-6 h-6 rounded-lg flex items-center justify-center
                          ${isRevenue
                            ? 'bg-brand-500/10 text-brand-400'
                            : 'bg-accent-red/10 text-accent-red'
                          }`}>
                          {isRevenue
                            ? <ArrowUpRight size={12} />
                            : <ArrowDownRight size={12} />
                          }
                        </span>
                        <span className="text-slate-200 text-xs leading-snug max-w-[200px] truncate">
                          {tx.description}
                        </span>
                      </div>
                    </td>
                    <td>
                      <span className={`badge text-[10px]
                        ${isRevenue
                          ? 'bg-brand-500/10 text-brand-400 border border-brand-500/20'
                          : 'bg-slate-500/10 text-slate-400 border border-slate-500/20'
                        }`}>
                        {capitalize(tx.category)}
                      </span>
                    </td>
                    <td className="text-xs text-slate-500 whitespace-nowrap">
                      {tx.branch?.split(' ')[0]}
                    </td>
                    <td className={`text-right font-mono font-semibold text-sm tabular-nums
                      ${isRevenue ? 'text-brand-400' : 'text-accent-red'}`}>
                      {isRevenue ? '+' : '-'}{formatBDT(tx.amount)}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
