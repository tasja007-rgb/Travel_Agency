/**
 * components/invoice/InvoiceGenerator.js
 * ─────────────────────────────────────────
 * Utility function that generates a downloadable, branded PDF invoice
 * using jsPDF + jspdf-autotable.
 *
 * Usage:
 *   import { generateInvoicePDF } from './InvoiceGenerator'
 *   generateInvoicePDF(bookingData)
 *
 * The bookingData object should match the sales_bookings row shape.
 */
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'

// ── Agency configuration (reads from .env, falls back to defaults) ───
const AGENCY = {
  name:    import.meta.env.VITE_AGENCY_NAME    ?? 'Horizon Travels & Tours',
  email:   import.meta.env.VITE_AGENCY_EMAIL   ?? 'info@horizontravels.com',
  phone:   import.meta.env.VITE_AGENCY_PHONE   ?? '+880-1700-000000',
  website: import.meta.env.VITE_AGENCY_WEBSITE ?? 'www.horizontravels.com',
}

// Branch-specific contact details
const BRANCH_ADDRESSES = {
  'Dhaka Branch':     { address: '45 Gulshan Avenue, Gulshan 1, Dhaka-1212', phone: '+880-1711-000001' },
  'Khulna Branch':    { address: '12 KDA Avenue, Khulna-9100',               phone: '+880-1722-000002' },
  'Chittagong Branch':{ address: '88 Agrabad Commercial Area, Chattogram',   phone: '+880-1733-000003' },
  'Sylhet Branch':    { address: '5 Zindabazar Road, Sylhet-3100',           phone: '+880-1744-000004' },
  'Head Office':      { address: '100 Motijheel C/A, Dhaka-1000',            phone: AGENCY.phone },
}

// ── Colour palette (as RGB arrays for jsPDF) ─────────────────
const COLORS = {
  navyDark:   [15,  23, 42],    // #0f172a
  navyMid:    [30,  41, 59],    // #1e293b
  skyBlue:    [14, 165, 233],   // #0ea5e9
  slate400:   [148,163,184],    // #94a3b8
  slate200:   [226,232,240],    // #e2e8f0
  white:      [255,255,255],
  green:      [16, 185,129],    // #10b981
  red:        [239, 68, 68],    // #ef4444
}

// ── Helper: format BDT ────────────────────────────────────────
function fmt(n) {
  if (!n && n !== 0) return '৳0'
  return '৳' + Number(n).toLocaleString('en-BD')
}

// ── Helper: format date ───────────────────────────────────────
function fmtDate(d) {
  if (!d) return '—'
  try {
    return new Date(d).toLocaleDateString('en-GB', {
      day: '2-digit', month: 'long', year: 'numeric'
    })
  } catch { return d }
}

// ── Helper: flatten JSONB service_details for the itemisation table ─
function buildServiceRows(booking) {
  const d = booking.service_details ?? {}
  const rows = []

  switch (booking.service_type) {
    case 'air_ticket':
      rows.push(['Airline',         d.airline        ?? '—'])
      rows.push(['Route',           d.route          ?? '—'])
      rows.push(['PNR Code',        d.pnr            ?? '—'])
      rows.push(['Departure Date',  fmtDate(d.departure_date)])
      if (d.return_date) rows.push(['Return Date', fmtDate(d.return_date)])
      rows.push(['Passengers',      d.passengers     ?? 1])
      rows.push(['Travel Class',    d.class          ?? '—'])
      break

    case 'hotel':
      rows.push(['Hotel',       d.hotel_name ?? '—'])
      rows.push(['City',        d.city       ?? '—'])
      rows.push(['Check-In',    fmtDate(d.check_in)])
      rows.push(['Check-Out',   fmtDate(d.check_out)])
      rows.push(['Rooms',       d.rooms      ?? 1])
      rows.push(['Room Type',   d.room_type  ?? '—'])
      break

    case 'visa':
      rows.push(['Country',         d.country         ?? '—'])
      rows.push(['Visa Type',       d.visa_type       ?? '—'])
      rows.push(['Travel Date',     fmtDate(d.travel_date)])
      rows.push(['Passport Expiry', fmtDate(d.passport_expiry)])
      if (d.duration) rows.push(['Duration', d.duration])
      break

    case 'tour_package':
      rows.push(['Package',     d.package_name  ?? '—'])
      rows.push(['Destination', d.destination   ?? '—'])
      rows.push(['Departure',   fmtDate(d.departure_date)])
      rows.push(['Return',      fmtDate(d.return_date)])
      rows.push(['Persons',     d.pax           ?? 1])
      if (d.inclusions) rows.push(['Inclusions', d.inclusions])
      break

    case 'esim':
      rows.push(['Country',      d.country         ?? '—'])
      rows.push(['Data Plan',    d.data_plan       ?? '—'])
      rows.push(['Provider',     d.provider        ?? '—'])
      rows.push(['Activation',   fmtDate(d.activation_date)])
      break

    case 'car_pickup_drop':
      rows.push(['Pickup',       d.pickup_location  ?? '—'])
      rows.push(['Drop',         d.drop_location    ?? '—'])
      rows.push(['Date/Time',    fmtDate(d.pickup_datetime)])
      rows.push(['Vehicle',      d.vehicle_type     ?? '—'])
      if (d.driver_name) rows.push(['Driver', d.driver_name])
      break

    default:
      rows.push(['Details', JSON.stringify(d)])
  }

  return rows
}

// ── SERVICE TYPE LABELS ───────────────────────────────────────
const SERVICE_LABELS = {
  air_ticket:      'Air Ticket',
  hotel:           'Hotel Reservation',
  visa:            'Visa Processing',
  tour_package:    'Tour Package',
  esim:            'eSIM',
  car_pickup_drop: 'Car Transfer',
}

// ══════════════════════════════════════════════════════════════
// MAIN EXPORT — generateInvoicePDF
// ══════════════════════════════════════════════════════════════
export function generateInvoicePDF(booking) {
  // ── Resolve branch details ──────────────────────────────────
  const branch = BRANCH_ADDRESSES[booking.branch] ?? BRANCH_ADDRESSES['Head Office']

  // ── Create PDF (A4) ─────────────────────────────────────────
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' })
  const PAGE_W   = 210
  const PAGE_H   = 297
  const MARGIN_X = 20
  const CONTENT_W = PAGE_W - MARGIN_X * 2

  let y = 0  // current Y cursor

  // ─────────────────────────────────────────────────────────────
  // HEADER BAND — dark navy background
  // ─────────────────────────────────────────────────────────────
  doc.setFillColor(...COLORS.navyDark)
  doc.rect(0, 0, PAGE_W, 42, 'F')

  // Sky-blue accent bar at very top
  doc.setFillColor(...COLORS.skyBlue)
  doc.rect(0, 0, PAGE_W, 3, 'F')

  // Agency name
  doc.setTextColor(...COLORS.white)
  doc.setFontSize(20)
  doc.setFont('helvetica', 'bold')
  doc.text(AGENCY.name, MARGIN_X, 18)

  // Agency tagline
  doc.setFontSize(8)
  doc.setFont('helvetica', 'normal')
  doc.setTextColor(...COLORS.slate400)
  doc.text('Your Trusted Travel Partner', MARGIN_X, 24)

  // Contact info — right aligned
  doc.setTextColor(...COLORS.slate400)
  doc.setFontSize(8)
  doc.text(AGENCY.email,   PAGE_W - MARGIN_X, 15, { align: 'right' })
  doc.text(branch.phone,   PAGE_W - MARGIN_X, 20, { align: 'right' })
  doc.text(AGENCY.website, PAGE_W - MARGIN_X, 25, { align: 'right' })
  doc.text(branch.address, PAGE_W - MARGIN_X, 30, { align: 'right' })

  y = 48

  // ─────────────────────────────────────────────────────────────
  // INVOICE TITLE + META
  // ─────────────────────────────────────────────────────────────
  doc.setFillColor(...COLORS.skyBlue)
  doc.setTextColor(...COLORS.white)
  doc.setFontSize(14)
  doc.setFont('helvetica', 'bold')
  doc.roundedRect(MARGIN_X, y, 55, 10, 2, 2, 'F')
  doc.text('INVOICE', MARGIN_X + 27.5, y + 7, { align: 'center' })

  // Invoice meta — right side
  doc.setTextColor(...COLORS.navyDark)
  doc.setFontSize(9)
  doc.setFont('helvetica', 'normal')
  const invoiceNo = booking.invoice_number ?? ('INV-' + booking.booking_ref)
  const issueDate = fmtDate(new Date().toISOString())

  doc.text(`Invoice No:   ${invoiceNo}`,        PAGE_W - MARGIN_X, y + 4,  { align: 'right' })
  doc.text(`Booking Ref:  ${booking.booking_ref}`, PAGE_W - MARGIN_X, y + 9,  { align: 'right' })
  doc.text(`Issue Date:   ${issueDate}`,         PAGE_W - MARGIN_X, y + 14, { align: 'right' })

  y += 20

  // Divider
  doc.setDrawColor(...COLORS.slate200)
  doc.setLineWidth(0.4)
  doc.line(MARGIN_X, y, PAGE_W - MARGIN_X, y)
  y += 6

  // ─────────────────────────────────────────────────────────────
  // BILLED TO section
  // ─────────────────────────────────────────────────────────────
  doc.setFontSize(7.5)
  doc.setFont('helvetica', 'bold')
  doc.setTextColor(...COLORS.skyBlue)
  doc.text('BILLED TO', MARGIN_X, y)
  y += 5

  doc.setTextColor(...COLORS.navyDark)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(11)
  doc.text(booking.client_name ?? '—', MARGIN_X, y)
  y += 5

  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.setTextColor(80, 90, 110)
  if (booking.client_phone) {
    doc.text(`📞  ${booking.client_phone}`, MARGIN_X, y)
    y += 5
  }
  if (booking.client_email) {
    doc.text(`✉  ${booking.client_email}`, MARGIN_X, y)
    y += 5
  }
  if (booking.client_passport) {
    doc.text(`🛂  Passport: ${booking.client_passport}`, MARGIN_X, y)
    y += 5
  }

  y += 4

  // ─────────────────────────────────────────────────────────────
  // SERVICE DETAILS TABLE
  // ─────────────────────────────────────────────────────────────
  const serviceLabel = SERVICE_LABELS[booking.service_type] ?? booking.service_type
  const serviceRows  = buildServiceRows(booking)

  doc.setFontSize(7.5)
  doc.setFont('helvetica', 'bold')
  doc.setTextColor(...COLORS.skyBlue)
  doc.text('SERVICE DETAILS', MARGIN_X, y)
  y += 4

  autoTable(doc, {
    startY: y,
    margin: { left: MARGIN_X, right: MARGIN_X },
    head: [['Field', 'Details']],
    body: serviceRows,
    theme: 'striped',
    headStyles: {
      fillColor: COLORS.navyDark,
      textColor: COLORS.white,
      fontStyle:  'bold',
      fontSize:   9,
      cellPadding: 4,
    },
    bodyStyles: {
      textColor: [30, 41, 59],
      fontSize:  9,
      cellPadding: 3.5,
    },
    alternateRowStyles: { fillColor: [241, 245, 249] },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 45, textColor: [14, 165, 233] },
      1: { cellWidth: 'auto' },
    },
  })

  y = doc.lastAutoTable.finalY + 8

  // ─────────────────────────────────────────────────────────────
  // FINANCIAL SUMMARY TABLE
  // ─────────────────────────────────────────────────────────────
  doc.setFontSize(7.5)
  doc.setFont('helvetica', 'bold')
  doc.setTextColor(...COLORS.skyBlue)
  doc.text('PAYMENT SUMMARY', MARGIN_X, y)
  y += 4

  autoTable(doc, {
    startY: y,
    margin: { left: MARGIN_X, right: MARGIN_X },
    body: [
      ['Service Type',   serviceLabel,                ''],
      ['Selling Price',  '',                           fmt(booking.selling_price)],
      ['Amount Paid',    '',                           fmt(booking.selling_price)],
    ],
    theme: 'plain',
    bodyStyles: { fontSize: 9, cellPadding: 3, textColor: [30, 41, 59] },
    columnStyles: {
      0: { cellWidth: 60, fontStyle: 'bold' },
      1: { cellWidth: 70 },
      2: { cellWidth: 40, halign: 'right', fontStyle: 'bold' },
    },
    didDrawCell: (data) => {
      // Draw a bold total row background for the last row
      if (data.row.index === 2 && data.section === 'body') {
        doc.setFillColor(...COLORS.navyDark)
      }
    },
  })

  y = doc.lastAutoTable.finalY

  // Bold "TOTAL" row
  doc.setFillColor(...COLORS.navyDark)
  doc.rect(MARGIN_X, y, CONTENT_W, 12, 'F')
  doc.setTextColor(...COLORS.white)
  doc.setFontSize(11)
  doc.setFont('helvetica', 'bold')
  doc.text('TOTAL AMOUNT PAID', MARGIN_X + 4, y + 8)
  doc.text(fmt(booking.selling_price), PAGE_W - MARGIN_X - 4, y + 8, { align: 'right' })
  y += 18

  // ─────────────────────────────────────────────────────────────
  // NOTES section (if any)
  // ─────────────────────────────────────────────────────────────
  if (booking.notes) {
    doc.setFontSize(7.5)
    doc.setFont('helvetica', 'bold')
    doc.setTextColor(...COLORS.skyBlue)
    doc.text('NOTES', MARGIN_X, y)
    y += 4

    doc.setFontSize(8.5)
    doc.setFont('helvetica', 'normal')
    doc.setTextColor(80, 90, 110)
    const noteLines = doc.splitTextToSize(booking.notes, CONTENT_W)
    doc.text(noteLines, MARGIN_X, y)
    y += noteLines.length * 5 + 4
  }

  // ─────────────────────────────────────────────────────────────
  // FOOTER BAND
  // ─────────────────────────────────────────────────────────────
  doc.setFillColor(...COLORS.navyDark)
  doc.rect(0, PAGE_H - 20, PAGE_W, 20, 'F')

  doc.setFillColor(...COLORS.skyBlue)
  doc.rect(0, PAGE_H - 3, PAGE_W, 3, 'F')

  doc.setTextColor(...COLORS.slate400)
  doc.setFontSize(7.5)
  doc.setFont('helvetica', 'normal')
  doc.text('Thank you for choosing ' + AGENCY.name + '. We wish you a wonderful journey!',
    PAGE_W / 2, PAGE_H - 13, { align: 'center' })
  doc.text(`This is a computer-generated invoice. No signature required.`,
    PAGE_W / 2, PAGE_H - 8, { align: 'center' })

  // ── Save / download ──────────────────────────────────────────
  const fileName = `Invoice_${booking.booking_ref}_${booking.client_name?.replace(/\s+/g, '_')}.pdf`
  doc.save(fileName)
}
