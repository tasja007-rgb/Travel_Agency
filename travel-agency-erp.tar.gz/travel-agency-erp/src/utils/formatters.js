/**
 * utils/formatters.js
 * ────────────────────
 * Pure helper functions for consistent formatting across the app.
 */

// ── Currency ────────────────────────────────────────────────────────────────

/**
 * Format a number as Bangladeshi Taka (BDT).
 * e.g. 65000 → "৳65,000"
 */
export function formatBDT(amount, compact = false) {
  if (amount == null || isNaN(amount)) return '৳0'
  const num = Number(amount)
  if (compact && Math.abs(num) >= 100000) {
    return '৳' + (num / 100000).toFixed(1) + 'L'
  }
  return '৳' + num.toLocaleString('en-BD')
}

// ── Dates ────────────────────────────────────────────────────────────────────

/**
 * Format a date string or Date object to "DD MMM YYYY".
 * e.g. "2024-08-15" → "15 Aug 2024"
 */
export function formatDate(dateStr) {
  if (!dateStr) return '—'
  const d = new Date(dateStr)
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
}

/**
 * Format a full datetime for display.
 * e.g. "2024-08-15T14:30:00" → "15 Aug 2024, 2:30 PM"
 */
export function formatDateTime(dateStr) {
  if (!dateStr) return '—'
  const d = new Date(dateStr)
  return d.toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  })
}

/**
 * Return relative time string: "2 hours ago", "3 days ago".
 */
export function timeAgo(dateStr) {
  if (!dateStr) return ''
  const seconds = Math.floor((Date.now() - new Date(dateStr)) / 1000)
  const intervals = [
    [31536000, 'year'], [2592000, 'month'], [86400, 'day'],
    [3600, 'hour'], [60, 'minute'],
  ]
  for (const [secs, label] of intervals) {
    const n = Math.floor(seconds / secs)
    if (n >= 1) return `${n} ${label}${n > 1 ? 's' : ''} ago`
  }
  return 'just now'
}

// ── Service Types ─────────────────────────────────────────────────────────────

const SERVICE_LABELS = {
  air_ticket:      '✈ Air Ticket',
  hotel:           '🏨 Hotel',
  visa:            '📋 Visa',
  tour_package:    '🌍 Tour Package',
  esim:            '📡 eSIM',
  car_pickup_drop: '🚗 Car Transfer',
}

export function formatServiceType(type) {
  return SERVICE_LABELS[type] || type
}

// ── Booking Status ─────────────────────────────────────────────────────────────

export const STATUS_STYLES = {
  pending:    'bg-accent-gold/10 text-accent-gold border border-accent-gold/30',
  confirmed:  'bg-brand-500/10 text-brand-400 border border-brand-500/30',
  processing: 'bg-accent-purple/10 text-accent-purple border border-accent-purple/30',
  completed:  'bg-accent-green/10 text-accent-green border border-accent-green/30',
  cancelled:  'bg-slate-500/10 text-slate-400 border border-slate-500/30',
  refunded:   'bg-accent-red/10 text-accent-red border border-accent-red/30',
}

export const VISA_STATUS_STYLES = {
  draft:      'bg-slate-500/10 text-slate-400 border border-slate-500/30',
  ready:      'bg-accent-gold/10 text-accent-gold border border-accent-gold/30',
  processing: 'bg-accent-purple/10 text-accent-purple border border-accent-purple/30',
  approved:   'bg-accent-green/10 text-accent-green border border-accent-green/30',
  rejected:   'bg-accent-red/10 text-accent-red border border-accent-red/30',
}

// ── Numbers ─────────────────────────────────────────────────────────────────

/**
 * Format a profit margin as a percentage string.
 * e.g. (10000, 65000) → "+15.4%"
 */
export function formatMargin(profit, revenue) {
  if (!revenue || revenue === 0) return '0%'
  const pct = ((profit / revenue) * 100).toFixed(1)
  return (pct >= 0 ? '+' : '') + pct + '%'
}

/**
 * Compact number formatting.
 * e.g. 1234567 → "1.2M", 123456 → "1.2L"
 */
export function compactNumber(n) {
  if (n == null) return '0'
  if (Math.abs(n) >= 1e7) return (n / 1e7).toFixed(1) + 'Cr'
  if (Math.abs(n) >= 1e5) return (n / 1e5).toFixed(1) + 'L'
  if (Math.abs(n) >= 1e3) return (n / 1e3).toFixed(1) + 'K'
  return String(n)
}

// ── Text ─────────────────────────────────────────────────────────────────────

export function capitalize(str) {
  if (!str) return ''
  return str.charAt(0).toUpperCase() + str.slice(1).replace(/_/g, ' ')
}

export function truncate(str, n = 30) {
  if (!str) return ''
  return str.length > n ? str.slice(0, n) + '…' : str
}
