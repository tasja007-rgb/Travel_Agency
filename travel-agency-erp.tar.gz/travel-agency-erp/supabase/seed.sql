-- ============================================================
-- SEED DATA — Run AFTER schema.sql
-- Creates realistic demo data for development and testing.
-- NOTE: Create auth users via Supabase Auth UI first, then
-- insert their UUIDs here as the `id` values.
-- ============================================================

-- ── Demo Users (replace UUIDs with real auth.users IDs) ──────
INSERT INTO public.users (id, full_name, email, role, branch, commission_rate, phone) VALUES
  ('11111111-0000-0000-0000-000000000001', 'Rafiqul Islam',    'admin@horizontravels.com',     'admin',       'Head Office',       0.00, '+880-1711-111111'),
  ('11111111-0000-0000-0000-000000000002', 'Nasrin Akter',     'manager.dhaka@horizontravels.com', 'manager',  'Dhaka Branch',     0.00, '+880-1722-222222'),
  ('11111111-0000-0000-0000-000000000003', 'Karim Hossain',    'agent1@horizontravels.com',    'agent',       'Dhaka Branch',      6.00, '+880-1733-333333'),
  ('11111111-0000-0000-0000-000000000004', 'Sumaya Begum',     'agent2@horizontravels.com',    'agent',       'Khulna Branch',     5.50, '+880-1744-444444'),
  ('11111111-0000-0000-0000-000000000005', 'Tanvir Ahmed',     'agent3@horizontravels.com',    'agent',       'Dhaka Branch',      5.00, '+880-1755-555555'),
  ('11111111-0000-0000-0000-000000000006', 'Fatema Khanam',    'accountant@horizontravels.com','accountant',  'Head Office',       0.00, '+880-1766-666666')
ON CONFLICT (id) DO NOTHING;

-- ── Demo Bookings ─────────────────────────────────────────────
INSERT INTO public.sales_bookings (
  booking_ref, agent_id, branch, client_name, client_phone, client_email,
  service_type, booking_status, selling_price, vendor_cost, service_details, notes
) VALUES

-- Air Tickets
('HT-2024-00001', '11111111-0000-0000-0000-000000000003', 'Dhaka Branch',
 'Mohammed Hasan', '+880-1811-000001', 'mhasan@email.com',
 'air_ticket', 'confirmed', 65000, 55000,
 '{"pnr":"ABCD12","airline":"Biman Bangladesh","route":"DAC-DXB","departure_date":"2024-09-01","return_date":"2024-09-15","passengers":1,"class":"Economy"}',
 'Business trip to Dubai'),

('HT-2024-00002', '11111111-0000-0000-0000-000000000004', 'Khulna Branch',
 'Roksana Parvin', '+880-1822-000002', NULL,
 'air_ticket', 'confirmed', 45000, 38000,
 '{"pnr":"EFGH34","airline":"Air Arabia","route":"DAC-SHJ","departure_date":"2024-09-10","return_date":null,"passengers":1,"class":"Economy"}',
 'One-way to Sharjah'),

-- Hotels
('HT-2024-00003', '11111111-0000-0000-0000-000000000003', 'Dhaka Branch',
 'Iqbal Hussain', '+880-1833-000003', 'iqbal@company.com',
 'hotel', 'confirmed', 35000, 28000,
 '{"hotel_name":"Millennium Airport Hotel","city":"Dubai","check_in":"2024-09-01","check_out":"2024-09-07","rooms":1,"room_type":"Superior"}',
 NULL),

-- Visas
('HT-2024-00004', '11111111-0000-0000-0000-000000000005', 'Dhaka Branch',
 'Salma Khatun', '+880-1844-000004', 'salma@email.com',
 'visa', 'processing', 15000, 9000,
 '{"country":"Malaysia","visa_type":"Tourist","passport_expiry":"2026-05-01","travel_date":"2024-10-01","duration":"30 days","documents":["passport_scan.pdf"]}',
 'Urgent processing requested'),

('HT-2024-00005', '11111111-0000-0000-0000-000000000004', 'Khulna Branch',
 'Jabbar Mia', '+880-1855-000005', NULL,
 'visa', 'approved', 18000, 11000,
 '{"country":"UAE","visa_type":"Tourist","passport_expiry":"2027-03-20","travel_date":"2024-08-20","duration":"30 days","documents":["passport_scan.pdf","bank_statement.pdf"]}',
 NULL),

-- Tour Packages
('HT-2024-00006', '11111111-0000-0000-0000-000000000003', 'Dhaka Branch',
 'Afsana Islam', '+880-1866-000006', 'afsana@email.com',
 'tour_package', 'confirmed', 120000, 90000,
 '{"package_name":"Thailand 6D5N","destination":"Bangkok & Pattaya","departure_date":"2024-10-15","return_date":"2024-10-20","pax":2,"inclusions":["hotel","breakfast","airport transfer","city tour"]}',
 'Honeymoon couple'),

-- eSIM
('HT-2024-00007', '11111111-0000-0000-0000-000000000005', 'Dhaka Branch',
 'Riyadh Ahmed', '+880-1877-000007', NULL,
 'esim', 'completed', 2500, 1800,
 '{"country":"Turkey","data_plan":"10GB/15days","provider":"Airalo","activation_date":"2024-08-25","iccid":"89012345678901234"}',
 NULL),

-- Car Pickup/Drop
('HT-2024-00008', '11111111-0000-0000-0000-000000000004', 'Khulna Branch',
 'Mazeda Begum', '+880-1888-000008', NULL,
 'car_pickup_drop', 'confirmed', 8000, 5500,
 '{"pickup_location":"Hazrat Shahjalal International Airport","drop_location":"Gulshan 2, Dhaka","pickup_datetime":"2024-09-01T16:00:00","vehicle_type":"Noah Microbus","driver_name":"Rahim","passengers":6}',
 'Family airport pickup'),

-- More bookings for richer dashboard data
('HT-2024-00009', '11111111-0000-0000-0000-000000000003', 'Dhaka Branch',
 'Khaled Mahmud', '+880-1899-000009', NULL,
 'air_ticket', 'confirmed', 72000, 60000,
 '{"pnr":"IJKL56","airline":"Emirates","route":"DAC-DXB-LHR","departure_date":"2024-11-01","return_date":"2024-11-20","passengers":1,"class":"Business"}',
 'UK student visa trip'),

('HT-2024-00010', '11111111-0000-0000-0000-000000000005', 'Dhaka Branch',
 'Nazneen Sultana', '+880-1900-000010', 'nazneen@email.com',
 'visa', 'draft', 12000, 7500,
 '{"country":"Canada","visa_type":"Visitor","passport_expiry":"2028-01-15","travel_date":"2025-01-01","duration":"6 months","documents":[]}',
 'Documents pending');

-- Set visa_status for visa bookings
UPDATE public.sales_bookings SET visa_status = 'processing' WHERE booking_ref = 'HT-2024-00004';
UPDATE public.sales_bookings SET visa_status = 'approved'   WHERE booking_ref = 'HT-2024-00005';
UPDATE public.sales_bookings SET visa_status = 'draft'      WHERE booking_ref = 'HT-2024-00010';

-- ── Demo Expense Transactions ─────────────────────────────────
INSERT INTO public.transactions (
  branch, type, category, expense_category, recorded_by,
  amount, description, transaction_date, payment_method, reference_no
) VALUES

('Dhaka Branch', 'expense', 'rent', 'rent',
 '11111111-0000-0000-0000-000000000006',
 85000, 'Office rent — Dhaka Branch — August 2024',
 '2024-08-01', 'bank_transfer', 'RENT-AUG-DHK'),

('Khulna Branch', 'expense', 'rent', 'rent',
 '11111111-0000-0000-0000-000000000006',
 45000, 'Office rent — Khulna Branch — August 2024',
 '2024-08-01', 'bank_transfer', 'RENT-AUG-KHL'),

('Head Office', 'expense', 'payroll', 'payroll',
 '11111111-0000-0000-0000-000000000006',
 320000, 'Staff salaries — August 2024 (all branches)',
 '2024-08-31', 'bank_transfer', 'SALARY-AUG-2024'),

('Dhaka Branch', 'expense', 'marketing', 'marketing',
 '11111111-0000-0000-0000-000000000006',
 25000, 'Facebook & Google Ads — August 2024',
 '2024-08-15', 'card', 'MKT-AUG-001'),

('Dhaka Branch', 'expense', 'utilities', 'utilities',
 '11111111-0000-0000-0000-000000000006',
 8500, 'Electricity & Internet — Dhaka Branch',
 '2024-08-10', 'cash', NULL),

('Khulna Branch', 'expense', 'office_supplies', 'office_supplies',
 '11111111-0000-0000-0000-000000000006',
 3200, 'Stationery, printer ink, forms',
 '2024-08-12', 'cash', NULL);
