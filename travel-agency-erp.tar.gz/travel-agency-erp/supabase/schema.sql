-- ============================================================
-- TRAVEL AGENCY ERP — SUPABASE DATABASE SCHEMA
-- Run this entire file in Supabase SQL Editor to initialize.
-- ============================================================

-- ── Enable UUID extension (already available in Supabase) ──
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- 1. CUSTOM TYPES (Enums)
-- ============================================================

-- Staff roles for access control
CREATE TYPE user_role AS ENUM ('admin', 'manager', 'agent', 'accountant');

-- All service types the agency sells
CREATE TYPE service_type AS ENUM (
  'air_ticket',
  'hotel',
  'visa',
  'tour_package',
  'esim',
  'car_pickup_drop'
);

-- Booking lifecycle states
CREATE TYPE booking_status AS ENUM (
  'pending',
  'confirmed',
  'processing',
  'completed',
  'cancelled',
  'refunded'
);

-- Visa-specific pipeline states (for Kanban board)
CREATE TYPE visa_status AS ENUM (
  'draft',
  'ready',
  'processing',
  'approved',
  'rejected'
);

-- Transaction directions
CREATE TYPE transaction_type AS ENUM ('revenue', 'expense');

-- Expense categories
CREATE TYPE expense_category AS ENUM (
  'rent',
  'payroll',
  'marketing',
  'utilities',
  'office_supplies',
  'travel',
  'miscellaneous'
);

-- Office branches
CREATE TYPE branch_location AS ENUM (
  'Dhaka Branch',
  'Khulna Branch',
  'Chittagong Branch',
  'Sylhet Branch',
  'Head Office'
);

-- ============================================================
-- 2. USERS TABLE
-- Extends Supabase auth.users with business profile data.
-- ============================================================
CREATE TABLE public.users (
  id                UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name         TEXT NOT NULL,
  email             TEXT NOT NULL UNIQUE,
  role              user_role NOT NULL DEFAULT 'agent',
  branch            branch_location NOT NULL DEFAULT 'Head Office',
  commission_rate   NUMERIC(5, 2) NOT NULL DEFAULT 5.00  -- percentage, e.g. 5.00 = 5%
                    CHECK (commission_rate >= 0 AND commission_rate <= 100),
  phone             TEXT,
  avatar_url        TEXT,
  is_active         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Auto-update the updated_at timestamp on row changes
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
  BEFORE UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- 3. SALES_BOOKINGS TABLE
-- Core operational hub. Uses JSONB `service_details` for
-- polymorphic service-specific data (PNRs, passport info, etc.)
-- ============================================================
CREATE TABLE public.sales_bookings (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

  -- Core identifiers
  booking_ref      TEXT NOT NULL UNIQUE,          -- e.g. "HT-2024-00123"
  agent_id         UUID NOT NULL REFERENCES public.users(id),
  branch           branch_location NOT NULL DEFAULT 'Head Office',

  -- Client information
  client_name      TEXT NOT NULL,
  client_email     TEXT,
  client_phone     TEXT NOT NULL,
  client_passport  TEXT,                           -- for visa/air ticket services

  -- Service classification
  service_type     service_type NOT NULL,
  booking_status   booking_status NOT NULL DEFAULT 'pending',

  -- Financial data
  selling_price    NUMERIC(12, 2) NOT NULL CHECK (selling_price >= 0),
  vendor_cost      NUMERIC(12, 2) NOT NULL CHECK (vendor_cost >= 0),
  -- Auto-calculated net profit via generated column
  net_profit       NUMERIC(12, 2) GENERATED ALWAYS AS (selling_price - vendor_cost) STORED,

  -- Visa-specific pipeline state (only relevant when service_type = 'visa')
  visa_status      visa_status,

  -- ── JSONB polymorphic payload ─────────────────────────────
  -- Air Ticket example:  { "pnr": "ABC123", "airline": "Biman", "route": "DAC-DXB",
  --                        "departure_date": "2024-08-15", "return_date": "2024-08-30",
  --                        "passengers": 2, "class": "Economy" }
  -- Hotel example:       { "hotel_name": "Grand Hyatt", "city": "Dubai",
  --                        "check_in": "2024-08-15", "check_out": "2024-08-20",
  --                        "rooms": 1, "room_type": "Deluxe" }
  -- Visa example:        { "country": "UAE", "visa_type": "Tourist",
  --                        "passport_expiry": "2027-01-01", "travel_date": "2024-08-15",
  --                        "documents": ["passport_copy.pdf", "bank_statement.pdf"] }
  -- Tour Package:        { "package_name": "Dubai 5D4N", "destination": "Dubai",
  --                        "departure_date": "2024-08-15", "pax": 4, "inclusions": ["hotel","transfer"] }
  -- eSIM example:        { "country": "UAE", "data_plan": "10GB/30days",
  --                        "provider": "Airalo", "activation_date": "2024-08-15" }
  -- Car example:         { "pickup_location": "DAC Airport", "drop_location": "Gulshan",
  --                        "pickup_datetime": "2024-08-15T14:00", "vehicle_type": "SUV",
  --                        "driver_name": "Karim" }
  service_details  JSONB NOT NULL DEFAULT '{}',

  -- Document references (Supabase Storage paths)
  documents        TEXT[] DEFAULT ARRAY[]::TEXT[],

  -- Invoice tracking
  invoice_number   TEXT UNIQUE,
  invoice_issued   BOOLEAN NOT NULL DEFAULT FALSE,

  -- Notes
  notes            TEXT,

  -- Timestamps
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- GIN index for fast JSONB querying (e.g. search by PNR, hotel name)
CREATE INDEX idx_bookings_service_details ON public.sales_bookings USING GIN (service_details);
CREATE INDEX idx_bookings_agent_id ON public.sales_bookings (agent_id);
CREATE INDEX idx_bookings_branch ON public.sales_bookings (branch);
CREATE INDEX idx_bookings_status ON public.sales_bookings (booking_status);
CREATE INDEX idx_bookings_service_type ON public.sales_bookings (service_type);
CREATE INDEX idx_bookings_created_at ON public.sales_bookings (created_at DESC);

CREATE TRIGGER trg_bookings_updated_at
  BEFORE UPDATE ON public.sales_bookings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Auto-generate booking reference (HT-YYYY-NNNNN)
CREATE OR REPLACE FUNCTION generate_booking_ref()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.booking_ref IS NULL OR NEW.booking_ref = '' THEN
    NEW.booking_ref := 'HT-' || TO_CHAR(NOW(), 'YYYY') || '-' ||
                       LPAD(CAST(FLOOR(RANDOM() * 99999 + 1) AS TEXT), 5, '0');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_generate_booking_ref
  BEFORE INSERT ON public.sales_bookings
  FOR EACH ROW EXECUTE FUNCTION generate_booking_ref();

-- ============================================================
-- 4. TRANSACTIONS TABLE
-- Financial ledger tracking both revenue (from bookings) and
-- operational expenses (rent, payroll, marketing, etc.)
-- ============================================================
CREATE TABLE public.transactions (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  branch           branch_location NOT NULL DEFAULT 'Head Office',

  -- Transaction classification
  type             transaction_type NOT NULL,
  category         TEXT NOT NULL,               -- 'air_ticket', 'hotel', 'rent', 'payroll', etc.
  expense_category expense_category,             -- populated only for expense transactions

  -- Link to booking (for revenue transactions; NULL for expenses)
  booking_id       UUID REFERENCES public.sales_bookings(id) ON DELETE SET NULL,
  recorded_by      UUID NOT NULL REFERENCES public.users(id),

  -- Financial data
  amount           NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
  description      TEXT NOT NULL,

  -- Date of the actual transaction (may differ from created_at)
  transaction_date DATE NOT NULL DEFAULT CURRENT_DATE,

  -- Payment method
  payment_method   TEXT DEFAULT 'cash',          -- 'cash', 'bank_transfer', 'card', 'bkash'

  -- Reference / receipt number
  reference_no     TEXT,

  -- Timestamps
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_transactions_branch ON public.transactions (branch);
CREATE INDEX idx_transactions_type ON public.transactions (type);
CREATE INDEX idx_transactions_date ON public.transactions (transaction_date DESC);
CREATE INDEX idx_transactions_booking_id ON public.transactions (booking_id);

CREATE TRIGGER trg_transactions_updated_at
  BEFORE UPDATE ON public.transactions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Auto-insert a revenue transaction when a booking is confirmed
CREATE OR REPLACE FUNCTION create_revenue_transaction_on_booking()
RETURNS TRIGGER AS $$
BEGIN
  IF (NEW.booking_status = 'confirmed' AND
      (OLD.booking_status IS NULL OR OLD.booking_status <> 'confirmed')) THEN
    INSERT INTO public.transactions (
      branch, type, category, booking_id, recorded_by,
      amount, description, transaction_date, payment_method
    ) VALUES (
      NEW.branch,
      'revenue',
      NEW.service_type::TEXT,
      NEW.id,
      NEW.agent_id,
      NEW.selling_price,
      'Revenue from booking ' || NEW.booking_ref || ' — ' || NEW.client_name,
      CURRENT_DATE,
      'cash'
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_auto_revenue_transaction
  AFTER INSERT OR UPDATE ON public.sales_bookings
  FOR EACH ROW EXECUTE FUNCTION create_revenue_transaction_on_booking();

-- ============================================================
-- 5. VIEWS (Convenient pre-built queries)
-- ============================================================

-- Daily financial summary per branch
CREATE OR REPLACE VIEW v_daily_financials AS
SELECT
  transaction_date,
  branch,
  SUM(CASE WHEN type = 'revenue' THEN amount ELSE 0 END)  AS total_revenue,
  SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END)  AS total_expenses,
  SUM(CASE WHEN type = 'revenue' THEN amount ELSE -amount END) AS net_profit
FROM public.transactions
GROUP BY transaction_date, branch
ORDER BY transaction_date DESC, branch;

-- Agent performance leaderboard
CREATE OR REPLACE VIEW v_agent_leaderboard AS
SELECT
  u.id          AS agent_id,
  u.full_name,
  u.branch,
  u.avatar_url,
  COUNT(b.id)                                              AS total_bookings,
  COALESCE(SUM(b.selling_price), 0)                        AS total_revenue,
  COALESCE(SUM(b.net_profit), 0)                           AS total_profit,
  COALESCE(SUM(b.net_profit) * u.commission_rate / 100, 0) AS commission_earned
FROM public.users u
LEFT JOIN public.sales_bookings b ON b.agent_id = u.id
  AND b.booking_status NOT IN ('cancelled', 'refunded')
WHERE u.role = 'agent' AND u.is_active = TRUE
GROUP BY u.id, u.full_name, u.branch, u.avatar_url, u.commission_rate
ORDER BY total_profit DESC;

-- Sales breakdown by category
CREATE OR REPLACE VIEW v_sales_by_category AS
SELECT
  service_type,
  COUNT(*)                   AS booking_count,
  SUM(selling_price)         AS total_revenue,
  SUM(net_profit)            AS total_profit,
  AVG(net_profit)            AS avg_profit_per_booking
FROM public.sales_bookings
WHERE booking_status NOT IN ('cancelled', 'refunded')
GROUP BY service_type;

-- ============================================================
-- 6. ROW LEVEL SECURITY (RLS)
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE public.users          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales_bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions   ENABLE ROW LEVEL SECURITY;

-- ── Helper: get current user's role ──────────────────────────
CREATE OR REPLACE FUNCTION get_my_role()
RETURNS user_role AS $$
  SELECT role FROM public.users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER;

-- ── USERS table policies ──────────────────────────────────────

-- Admins can see and manage all users
CREATE POLICY "admin_all_users" ON public.users
  AS PERMISSIVE FOR ALL TO authenticated
  USING (get_my_role() = 'admin')
  WITH CHECK (get_my_role() = 'admin');

-- All authenticated staff can view their own profile
CREATE POLICY "own_profile_select" ON public.users
  AS PERMISSIVE FOR SELECT TO authenticated
  USING (id = auth.uid());

-- Staff can update their own non-sensitive fields
CREATE POLICY "own_profile_update" ON public.users
  AS PERMISSIVE FOR UPDATE TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid() AND role = get_my_role()); -- cannot self-escalate role

-- Managers can view all users in the same branch
CREATE POLICY "manager_view_branch_users" ON public.users
  AS PERMISSIVE FOR SELECT TO authenticated
  USING (
    get_my_role() = 'manager' AND
    branch = (SELECT branch FROM public.users WHERE id = auth.uid())
  );

-- ── SALES_BOOKINGS table policies ────────────────────────────

-- Admins have full access to all bookings
CREATE POLICY "admin_all_bookings" ON public.sales_bookings
  AS PERMISSIVE FOR ALL TO authenticated
  USING (get_my_role() = 'admin')
  WITH CHECK (get_my_role() = 'admin');

-- Managers can see all bookings in their branch
CREATE POLICY "manager_branch_bookings" ON public.sales_bookings
  AS PERMISSIVE FOR SELECT TO authenticated
  USING (
    get_my_role() = 'manager' AND
    branch = (SELECT branch FROM public.users WHERE id = auth.uid())
  );

-- Managers can update bookings in their branch (e.g., approve, change status)
CREATE POLICY "manager_update_branch_bookings" ON public.sales_bookings
  AS PERMISSIVE FOR UPDATE TO authenticated
  USING (
    get_my_role() = 'manager' AND
    branch = (SELECT branch FROM public.users WHERE id = auth.uid())
  );

-- Agents can only see their own bookings
CREATE POLICY "agent_own_bookings_select" ON public.sales_bookings
  AS PERMISSIVE FOR SELECT TO authenticated
  USING (get_my_role() = 'agent' AND agent_id = auth.uid());

-- Agents can create their own bookings
CREATE POLICY "agent_own_bookings_insert" ON public.sales_bookings
  AS PERMISSIVE FOR INSERT TO authenticated
  WITH CHECK (get_my_role() = 'agent' AND agent_id = auth.uid());

-- Agents can update only their own pending bookings
CREATE POLICY "agent_own_bookings_update" ON public.sales_bookings
  AS PERMISSIVE FOR UPDATE TO authenticated
  USING (
    get_my_role() = 'agent' AND
    agent_id = auth.uid() AND
    booking_status = 'pending'
  );

-- Accountants can view all bookings (read-only for financial reporting)
CREATE POLICY "accountant_view_all_bookings" ON public.sales_bookings
  AS PERMISSIVE FOR SELECT TO authenticated
  USING (get_my_role() = 'accountant');

-- ── TRANSACTIONS table policies ───────────────────────────────

-- Admins can do everything
CREATE POLICY "admin_all_transactions" ON public.transactions
  AS PERMISSIVE FOR ALL TO authenticated
  USING (get_my_role() = 'admin')
  WITH CHECK (get_my_role() = 'admin');

-- Accountants can view and insert all transactions
CREATE POLICY "accountant_manage_transactions" ON public.transactions
  AS PERMISSIVE FOR ALL TO authenticated
  USING (get_my_role() = 'accountant')
  WITH CHECK (get_my_role() = 'accountant');

-- Managers can view transactions for their branch
CREATE POLICY "manager_branch_transactions" ON public.transactions
  AS PERMISSIVE FOR SELECT TO authenticated
  USING (
    get_my_role() = 'manager' AND
    branch = (SELECT branch FROM public.users WHERE id = auth.uid())
  );

-- Agents can only see revenue transactions linked to their bookings
CREATE POLICY "agent_own_transactions" ON public.transactions
  AS PERMISSIVE FOR SELECT TO authenticated
  USING (
    get_my_role() = 'agent' AND
    type = 'revenue' AND
    booking_id IN (
      SELECT id FROM public.sales_bookings WHERE agent_id = auth.uid()
    )
  );

-- ============================================================
-- 7. SUPABASE STORAGE BUCKET (for visa documents)
-- ============================================================
-- Run this after creating the bucket named 'booking-documents' in Storage UI
-- Or execute via Supabase Storage API. The SQL below sets the policy.

-- INSERT INTO storage.buckets (id, name, public) VALUES ('booking-documents', 'booking-documents', false);

-- Allow authenticated users to upload to their own folder
CREATE POLICY "auth_upload_documents" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'booking-documents' AND auth.role() = 'authenticated');

CREATE POLICY "auth_view_documents" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'booking-documents');

CREATE POLICY "admin_delete_documents" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'booking-documents' AND get_my_role() IN ('admin', 'manager'));

-- ============================================================
-- 8. REALTIME (enable for live dashboard updates)
-- ============================================================
-- Enable realtime on key tables (run in Supabase dashboard or here)
ALTER PUBLICATION supabase_realtime ADD TABLE public.sales_bookings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.transactions;
